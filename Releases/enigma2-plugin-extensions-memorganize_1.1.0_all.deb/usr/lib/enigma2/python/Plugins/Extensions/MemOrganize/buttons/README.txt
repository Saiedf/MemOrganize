MemOrganize button image folder.
Preferred filenames:
red.png green.png yellow.png blue.png ok.png menu.png info.png settings.png swap.png
Alternative names such as button_red.png / key_red.png are also detected at runtime.
Copy your original button PNG files here before installing the plugin.
