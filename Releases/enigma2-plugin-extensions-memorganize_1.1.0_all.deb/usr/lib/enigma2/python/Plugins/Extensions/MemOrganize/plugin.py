# -*- coding: utf-8 -*-
# Memory Organize Plugin By iet5
# Added Display Name Formatting for Enigma2 Core

import os
import sys
import time
import json
import fnmatch
import subprocess
import threading
import tempfile
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ConfigList import ConfigListScreen
from Components.ScrollLabel import ScrollLabel
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.config import config, ConfigSubsection, ConfigYesNo, ConfigSelection, ConfigText, getConfigListEntry, configfile
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from enigma import eTimer
from skin import loadSkin

try:
    from twisted.internet import reactor as twisted_reactor
except Exception:
    twisted_reactor = None

PLUGIN_PATH = resolveFilename(SCOPE_PLUGINS, "Extensions/MemOrganize/")
BUTTONS_PATH = os.path.join(PLUGIN_PATH, 'buttons')
DEFAULT_HISTORY_DIRNAME = "MemOrganize"
HISTORY_FILE_NAME = "mem_history.json"
MAX_HISTORY_ITEMS = 300
SNAPSHOT_TOP_COUNT = 20
WHITELIST = ['enigma2', 'init', 'systemd', 'kthreadd', 'rcS', 'sh', 'bash', 'sshd', 'telnetd', 'vsftpd', 'smbd']

PROCESS_DESCRIPTIONS = {
    'enigma2': 'Enigma2 Main GUI',
    'enigma2.sh': 'Enigma2 Startup Script',
    'enigma2 Core': 'Enigma2 Platform Core',
    'enigma2 Plugins': 'Enigma2 Installed Addons',
    'enigma2 (Core + Plugins)': 'Enigma2 GUI',
    'vsftpd': 'FTP Server',
    'smbd': 'Samba File Sharing',
    'nmbd': 'Samba NetBIOS',
    'dropbear': 'SSH Server',
    'sshd': 'SSH Server',
    'in.telnetd': 'Telnet Server',
    'automount': 'USB/HDD Auto-Mount',
    'oscam': 'OSCam Emulator',
    'ncam': 'NCam Emulator',
    'cccam': 'CCcam Emulator',
    'mgcamd': 'MGCamd Emulator',
    'wicardd': 'Wicardd Emulator',
    'gbox': 'GBox Emulator',
    'oscam-emu': 'OSCam-Emu',
    'oscam-smod': 'OSCam-Smod Emulator',
    'streamproxy': 'Streaming Proxy Server',
    'udpxy': 'UDP-to-HTTP Streaming Proxy',
    'minidlna': 'MiniDLNA Media Server',
    'exteplayer3': 'E2iPlayer Media Engine',
    'ffmpeg': 'Media Converting/Streaming Tool',
    'gst-launch-1.0': 'GStreamer Media Engine',
    'lcd4linux': 'Front-Panel Display Driver',
    'avahi-daemon': 'ZeroConf Discovery',
    'udevd': 'Linux Device Manager',
    'systemd-udevd': 'Linux Device Manager',
    'crond': 'Scheduled Tasks',
    'dbus-daemon': 'System Message Bus',
    'wpa_supplicant': 'Wi-Fi Connection Manager',
    'connmand': 'Network Manager',
    'connmand.real': 'Network Connection Manager',
    'chronyd': 'Time Synchronization',
    'ntpdate': 'Time Synchronization',
    'systemd-timesyn': 'Time Synchronization',
    'lighttpd': 'Web Server (OpenWebif)',
    'nginx': 'Web Server',
    'openvpn': 'VPN Client',
    'syslogd': 'System Logger',
    'klogd': 'Kernel Logger',
    'systemd-journal': 'System Journal Logger',
    'systemd-logind': 'System Login Manager',
    'systemd-resolve': 'Network Name Resolution',
    'dnsmasq': 'DNS/DHCP Server',
    'hostapd': 'Wi-Fi Hotspot Daemon',
    'pure-ftpd': 'Pure-FTPd Server',
    'proftpd': 'ProFTPd Server',
    'zerotier-one': 'ZeroTier VPN Daemon',
    'wg-quick': 'WireGuard VPN',
    'tailscaled': 'Tailscale VPN Daemon',
    'bluetoothd': 'Bluetooth Service',
    'hidd': 'Bluetooth Input Device Daemon',
    'rpcbind': 'RPC Portmapper',
    'nfsd': 'NFS Server Daemon',
    'mountd': 'NFS Mount Daemon',
    'statd': 'NFS Status Monitor',
    'sleep': 'Background Sleep Timer',
    'shellinaboxd': 'Web Terminal Interface',
    'transmission-da': 'Transmission Torrent Client',
    'wget': 'File Download/Request',
    'curl': 'Network Request',
    'cleanupd': 'Samba/System Cleanup Daemon',
    'lpqd': 'Printer Spooler Daemon',
    'dbttcd': 'Dreambox Bluetooth Daemon',
    'tpmd': 'Hardware Security/Authentication Daemon',
    'hdparm': 'HDD Power/Spindown Manager',
    'e2fsck': 'File System Checker',
    'fsck': 'File System Checker',
    'smartd': 'Disk Health Monitor',
    'dockerd': 'Docker Container Engine',
    'containerd': 'Container Engine',
    'init': 'System Initializer',
    'systemd': 'System & Service Manager',
    'kthreadd': 'Kernel Thread Manager',
    'rcS': 'System Boot Script',
    'bash': 'Command Shell',
    'sh': 'Command Shell'
}

config.plugins.MemOrganize = ConfigSubsection()
config.plugins.MemOrganize.run_on_boot = ConfigYesNo(default=False)
config.plugins.MemOrganize.run_in_bg = ConfigYesNo(default=False)
config.plugins.MemOrganize.monitor_interval = ConfigSelection(default='60', choices=[('30','30 sec'),('60','1 min'),('120','2 min'),('300','5 min')])
config.plugins.MemOrganize.swap_size = ConfigSelection(default='256', choices=[('64','64 MB'),('128','128 MB'),('256','256 MB'),('512','512 MB'),('1024','1024 MB'),('2048','2 GB'),('4096','4 GB'),('8192','8 GB'),('16384','16 GB')])
config.plugins.MemOrganize.swap_path = ConfigText(default='/media/hdd/swapfile')
config.plugins.MemOrganize.swap_autoenable = ConfigYesNo(default=False)
config.plugins.MemOrganize.swappiness = ConfigSelection(default='10', choices=[('1','1 - minimal'),('5','5'),('10','10 - recommended'),('20','20'),('30','30'),('60','60 - Linux default')])
config.plugins.MemOrganize.warn_ram_percent = ConfigSelection(default='90', choices=[('80','80%'),('85','85%'),('90','90%'),('95','95%')])
config.plugins.MemOrganize.warn_flash_percent = ConfigSelection(default='90', choices=[('80','80%'),('85','85%'),('90','90%'),('95','95%')])

bg_timer = None
bg_timer_conn = None
bg_worker_running = False
history_lock = threading.Lock()

try:
    loadSkin(os.path.join(PLUGIN_PATH, "skin.xml"))
except Exception as e:
    print("[MemOrganize] Skin error: %s" % str(e))


PY2 = sys.version_info.major == 2
PY3 = sys.version_info.major == 3
PY312_PLUS = PY3 and sys.version_info.minor >= 12

isDreamOS = False
isOpenSource = False

if os.path.exists('/var/lib/dpkg/status'):
    isDreamOS = True
else:
    isOpenSource = True

def bind_timer(timer_obj, callback):
    # DreamOS mostly uses callback.append
    if isDreamOS:
        try:
            timer_obj.callback.append(callback)
            return None
        except AttributeError:
            pass
            
    # Open Source (OE-A) Python 3.12+ MUST return and hold connection reference
    if isOpenSource and PY312_PLUS:
        try:
            return timer_obj.timeout.connect(callback)
        except Exception:
            pass

    # Older Open Source / Fallback
    try:
        timer_obj.timeout.connect(callback)
        return None
    except Exception:
        try:
            timer_obj.callback.append(callback)
        except Exception:
            pass
        return None


class BackgroundJob(object):
    """Run slow disk/process work without blocking the Enigma2 UI thread."""
    def __init__(self):
        self.timer = eTimer()
        self.timer_conn = bind_timer(self.timer, self._poll)
        self.running = False
        self.finished = False
        self.success = False
        self.result = None
        self.callback = None
        self.closed = False

    def start(self, worker, callback=None, *args):
        if self.running or self.closed:
            return False
        self.running = True
        self.finished = False
        self.success = False
        self.result = None
        self.callback = callback
        thread = threading.Thread(target=self._run, args=(worker, args))
        thread.setDaemon(True)
        thread.start()
        self.timer.start(200, False)
        return True

    def _run(self, worker, args):
        try:
            self.result = worker(*args)
            self.success = True
        except Exception as error:
            self.result = error
            append_runtime_log('Background job', error)
        self.finished = True
        if twisted_reactor is not None:
            try:
                twisted_reactor.callFromThread(self._poll)
            except Exception:
                pass

    def _poll(self):
        if not self.finished or not self.running:
            return
        try:
            self.timer.stop()
        except Exception:
            pass
        callback = self.callback
        success = self.success
        result = self.result
        self.callback = None
        self.running = False
        self.finished = False
        if callback is not None and not self.closed:
            try:
                callback(success, result)
            except Exception as error:
                append_runtime_log('Background callback', error)

    def close(self):
        self.closed = True
        self.callback = None
        try:
            self.timer.stop()
        except Exception:
            pass


def start_detached_job(worker, *args):
    """Start fire-and-forget maintenance work with no UI access."""
    try:
        thread = threading.Thread(target=worker, args=args)
        thread.setDaemon(True)
        thread.start()
        return True
    except Exception as error:
        append_runtime_log('Detached job', error)
        return False

def to_unicode(value):
    if PY3:
        if isinstance(value, str):
            return value
        elif isinstance(value, bytes):
            return value.decode('utf-8', 'ignore')
        else:
            return str(value)
    else:
        # Python 2 behavior
        if isinstance(value, unicode):
            return value
        elif isinstance(value, str):
            try:
                return value.decode('utf-8', 'ignore')
            except Exception:
                return str(value)
        else:
            try:
                return str(value).decode('utf-8', 'ignore')
            except Exception:
                return str(value)


def to_display_string(value):
    # Keep Listbox text compatible with both Python 2 and Python 3 images.
    if value is None:
        value = ''
    uval = to_unicode(value)
    if not PY3:
        try:
            return uval.encode('utf-8', 'ignore')
        except Exception:
            return str(uval)
    return str(uval)


def safe_mkdir(path):
    try:
        if not os.path.exists(path):
            os.makedirs(path)
        return os.path.isdir(path)
    except Exception as e:
        print("[MemOrganize] mkdir error for %s: %s" % (path, str(e)))
        return False


def get_candidate_history_roots():
    roots = []
    for candidate in [
        '/data', '/media/mmc', '/media/usb', '/media/hdd', '/hdd', '/autofs/sda1', '/autofs/sdb1', '/media/net/hdd'
    ]:
        if candidate not in roots:
            roots.append(candidate)
    return roots


def get_history_paths():
    for root in get_candidate_history_roots():
        try:
            if root == '/data' and not os.path.ismount(root):
                continue
            if os.path.isdir(root) and os.access(root, os.W_OK):
                folder = os.path.join(root, DEFAULT_HISTORY_DIRNAME)
                if safe_mkdir(folder):
                    return folder, os.path.join(folder, HISTORY_FILE_NAME)
        except Exception:
            pass
    fallback = '/tmp/%s' % DEFAULT_HISTORY_DIRNAME
    safe_mkdir(fallback)
    return fallback, os.path.join(fallback, HISTORY_FILE_NAME)


def read_json_file(path, default=None):
    if default is None:
        default = {}
    try:
        if os.path.exists(path):
            if PY3:
                f = open(path, 'r', encoding='utf-8')
            else:
                f = open(path, 'r')
            try:
                data = json.load(f)
            finally:
                f.close()
            return data
    except Exception as e:
        print("[MemOrganize] json read error: %s" % str(e))
    return default


def write_json_file(path, data):
    try:
        folder = os.path.dirname(path)
        safe_mkdir(folder)
        tmp = path + '.tmp'
        if PY3:
            f = open(tmp, 'w', encoding='utf-8')
        else:
            f = open(tmp, 'w')
        try:
            json.dump(data, f)
        finally:
            f.close()
        os.rename(tmp, path)
        return True
    except Exception as e:
        print("[MemOrganize] json write error: %s" % str(e))
        return False


def append_runtime_log(context, error):
    try:
        line = '%s | %s | %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), context, to_unicode(error))
        f = open('/tmp/MemOrganize_runtime.log', 'ab')
        try:
            f.write(line.encode('utf-8', 'replace'))
        finally:
            f.close()
    except Exception:
        pass



BUTTON_ALIASES = {
    'red': ['red.png','button_red.png','key_red.png','redbutton.png'],
    'green': ['green.png','button_green.png','key_green.png','greenbutton.png'],
    'yellow': ['yellow.png','button_yellow.png','key_yellow.png','yellowbutton.png'],
    'blue': ['blue.png','button_blue.png','key_blue.png','bluebutton.png'],
    'ok': ['ok.png','button_ok.png','key_ok.png'],
    'menu': ['menu.png','button_menu.png','key_menu.png'],
    'info': ['info.png','button_info.png','key_info.png'],
    'settings': ['settings.png','setting.png','setup.png'],
    'swap': ['swap.png','button_swap.png']
}

def find_button_image(kind):
    for name in BUTTON_ALIASES.get(kind, []):
        path = os.path.join(BUTTONS_PATH, name)
        if os.path.isfile(path):
            return path
    try:
        if os.path.isdir(BUTTONS_PATH):
            lowkind = kind.lower()
            for name in os.listdir(BUTTONS_PATH):
                lname = name.lower()
                if lname.endswith(('.png','.jpg','.jpeg')) and lowkind in lname:
                    return os.path.join(BUTTONS_PATH, name)
    except Exception:
        pass
    return ''

def apply_button_icons(screen, mapping):
    for widget_name, kind in mapping.items():
        try:
            path = find_button_image(kind)
            if path:
                screen[widget_name].instance.setPixmapFromFile(path)
                screen[widget_name].show()
            else:
                screen[widget_name].hide()
        except Exception:
            pass

def get_total_cpu_ticks():
    try:
        f = open('/proc/stat','r')
        try:
            parts = f.readline().split()[1:]
        finally:
            f.close()
        return sum([int(x) for x in parts])
    except Exception:
        return 0

def get_proc_cpu_ticks(pid):
    try:
        f = open('/proc/%s/stat' % pid, 'r')
        try:
            line = f.read().strip()
        finally:
            f.close()
        rparen = line.rfind(')')
        fields = line[rparen+2:].split()
        return int(fields[11]) + int(fields[12])
    except Exception:
        return 0

def get_cpu_count():
    try:
        n = 0
        f = open('/proc/stat','r')
        try:
            for line in f:
                if line.startswith('cpu') and len(line) > 3 and line[3].isdigit():
                    n += 1
        finally:
            f.close()
        return max(1,n)
    except Exception:
        return 1

def get_system_health(include_process_states=True):
    health = {'load1':0.0,'load5':0.0,'load15':0.0,'zombies':0,'processes':0,'uptime':0.0}
    try:
        vals = open('/proc/loadavg','r').read().split()
        health['load1'],health['load5'],health['load15'] = float(vals[0]),float(vals[1]),float(vals[2])
    except Exception:
        pass
    try:
        health['uptime'] = float(open('/proc/uptime','r').read().split()[0])
    except Exception:
        pass
    try:
        process_ids = [pid for pid in os.listdir('/proc') if pid.isdigit()]
        health['processes'] = len(process_ids)
        if not include_process_states:
            return health
        for pid in process_ids:
            try:
                f=open('/proc/%s/status'%pid,'r')
                try:
                    for line in f:
                        if line.startswith('State:'):
                            if '\tZ' in line or ' Z ' in line:
                                health['zombies'] += 1
                            break
                finally:
                    f.close()
            except Exception:
                pass
    except Exception:
        pass
    return health

def get_mount_for_path(path):
    best = None
    for dev,mountp,fstype in get_mount_points():
        if path == mountp or path.startswith(mountp.rstrip('/') + '/'):
            if best is None or len(mountp) > len(best[1]):
                best = (dev,mountp,fstype)
    return best

def get_active_swaps():
    out=[]
    try:
        f=open('/proc/swaps','r')
        try:
            lines=f.readlines()[1:]
        finally:
            f.close()
        for line in lines:
            p=line.split()
            if len(p)>=5:
                out.append({'path':p[0],'type':p[1],'size_kb':int(p[2]),'used_kb':int(p[3]),'priority':p[4]})
    except Exception:
        pass
    return out

def swap_is_active(path):
    for item in get_active_swaps():
        if item.get('path') == path:
            return True
    return False


def run_quiet_command(arguments, timeout_seconds=120):
    devnull = None
    process = None
    try:
        devnull = open(os.devnull, 'wb')
        process = subprocess.Popen(arguments, stdout=devnull, stderr=devnull)
        deadline = time.time() + max(1, int(timeout_seconds))
        while process.poll() is None and time.time() < deadline:
            time.sleep(0.10)
        if process.poll() is not None:
            return process.returncode
        try:
            process.terminate()
        except Exception:
            pass
        stop_deadline = time.time() + 2.0
        while process.poll() is None and time.time() < stop_deadline:
            time.sleep(0.05)
        if process.poll() is None:
            try:
                process.kill()
            except Exception:
                pass
        return -2
    except Exception:
        return -1
    finally:
        try:
            if devnull is not None:
                devnull.close()
        except Exception:
            pass


def capture_command_output(arguments, limit=262144, timeout_seconds=15):
    """Capture bounded command output without shell parsing or endless waits."""
    output_file = None
    process = None
    try:
        output_file = tempfile.TemporaryFile()
        process = subprocess.Popen(arguments, stdout=output_file, stderr=output_file)
        deadline = time.time() + max(1, int(timeout_seconds))
        while process.poll() is None and time.time() < deadline:
            time.sleep(0.10)
        if process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
            stop_deadline = time.time() + 2.0
            while process.poll() is None and time.time() < stop_deadline:
                time.sleep(0.05)
            if process.poll() is None:
                try:
                    process.kill()
                except Exception:
                    pass
            return ''
        output_file.seek(0)
        return to_unicode(output_file.read(limit))
    except Exception:
        return ''
    finally:
        try:
            if output_file is not None:
                output_file.close()
        except Exception:
            pass


def perform_cache_cleanup():
    """Flush and release caches in a worker thread; sync may block slow disks."""
    before_mem = read_meminfo_kb()
    before_cache = before_mem.get('Cached:', 0) + before_mem.get('SReclaimable:', 0)
    ret = run_quiet_command(['sync'])
    try:
        f = open('/proc/sys/vm/drop_caches', 'w')
        try:
            f.write('3\n')
        finally:
            f.close()
    except Exception:
        ret = 1
    after_mem = read_meminfo_kb()
    after = int(get_available_kb(after_mem) / 1024)
    after_cache = after_mem.get('Cached:', 0) + after_mem.get('SReclaimable:', 0)
    released = max(0, int((before_cache - after_cache) / 1024))
    if ret == 0:
        append_history_event('action', 'Safe memory cache cleanup', details='drop_caches=3 | released=%d MB' % released)
    else:
        append_history_event('error', 'File cache cleanup failed', details='Command returned=%s' % str(ret))
    return ret, released, after


def has_swap_signature(path):
    try:
        if not os.path.isfile(path) or os.path.islink(path):
            return False
        page_size = 4096
        try:
            page_size = int(os.sysconf('SC_PAGE_SIZE'))
        except Exception:
            pass
        f = open(path, 'rb')
        try:
            f.seek(max(0, page_size - 10))
            signature = f.read(10)
        finally:
            f.close()
        return signature in [b'SWAPSPACE2', b'SWAP-SPACE']
    except Exception:
        return False

def validate_swap_location(path, size_mb):
    if any(ch in path for ch in ['"', '`', '$', '\n', '\r']):
        return False, 'The selected path contains unsupported characters.'
    parent=os.path.dirname(path) or '/'
    if not os.path.isdir(parent):
        return False, 'Folder does not exist: %s' % parent
    if not os.access(parent, os.W_OK):
        return False, 'Folder is not writable: %s' % parent
    mount=get_mount_for_path(parent)
    if mount:
        fstype=(mount[2] or '').lower()
        if fstype in ['vfat','fat','msdos','exfat','ntfs','ntfs-3g','cifs','nfs','nfs4','fuseblk','squashfs','overlay','btrfs']:
            return False, 'Filesystem %s is not recommended/supported for this swap-file method.' % fstype
    total,used,free=get_fs_numbers(parent)
    need=(int(size_mb)+32)*1024*1024
    if free and free < need:
        return False, 'Not enough free space. Need about %d MB.' % (int(size_mb)+32)
    if path == '/swapfile':
        return True, 'Internal flash selected. Frequent swap writes may shorten flash life.'
    return True, 'Location OK.'

def create_swap_file(path, size_mb):
    ok,msg=validate_swap_location(path,size_mb)
    if not ok:
        return False,msg
    if os.path.lexists(path):
        return False,'Swap file already exists.'
    rc = -1
    fallocate = '/usr/bin/fallocate' if os.path.exists('/usr/bin/fallocate') else '/bin/fallocate'
    if os.path.exists(fallocate):
        rc = run_quiet_command([fallocate, '-l', '%dM' % int(size_mb), path], timeout_seconds=300)
    if rc != 0:
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception:
            pass
        rc = run_quiet_command(['dd', 'if=/dev/zero', 'of=%s' % path, 'bs=1M', 'count=%d' % int(size_mb)], timeout_seconds=900)
    if rc == 0:
        try:
            os.chmod(path, 0o600)
        except Exception:
            rc = -1
    if rc == 0:
        rc = run_quiet_command(['mkswap', path], timeout_seconds=60)
    if rc != 0:
        try:
            if os.path.exists(path): os.remove(path)
        except Exception: pass
        return False,'Could not create/format swap file.'
    return True,'Swap file created successfully.'

def enable_swap_file(path):
    if swap_is_active(path):
        return True,'Swap is already active.'
    if not os.path.exists(path):
        return False,'Swap file does not exist.'
    apply_swappiness()
    if not has_swap_signature(path):
        return False,'The selected file is not a valid swap file.'
    rc=run_quiet_command(['swapon', path], timeout_seconds=30)
    return (rc==0, 'Swap enabled.' if rc==0 else 'swapon failed.')

def disable_swap_file(path):
    if not swap_is_active(path):
        return True,'Swap is already disabled.'
    rc=run_quiet_command(['swapoff', path], timeout_seconds=180)
    return (rc==0, 'Swap disabled.' if rc==0 else 'swapoff failed (possibly in use).')

def remove_swap_file(path):
    if not has_swap_signature(path):
        return False,'Delete refused: the selected path is not a verified swap file.'
    if swap_is_active(path):
        ok,msg=disable_swap_file(path)
        if not ok: return False,msg
    try:
        if os.path.exists(path): os.remove(path)
        return True,'Swap file removed.'
    except Exception as e:
        return False,'Delete failed: %s' % str(e)

def get_swappiness():
    try:
        return int(open('/proc/sys/vm/swappiness','r').read().strip())
    except Exception:
        return -1

def apply_swappiness():
    try:
        value=int(config.plugins.MemOrganize.swappiness.value)
        f=open('/proc/sys/vm/swappiness','w')
        try: f.write(str(value))
        finally: f.close()
        return True
    except Exception:
        return False

def auto_enable_configured_swap():
    if not config.plugins.MemOrganize.swap_autoenable.value:
        return
    path=config.plugins.MemOrganize.swap_path.value
    if os.path.exists(path):
        apply_swappiness()
        enable_swap_file(path)

def get_proc_name_from_pid(pid):
    try:
        f = open('/proc/%s/status' % pid, 'r')
        try:
            for line in f:
                if line.startswith('Name:'):
                    return line.split()[1].strip()
        finally:
            f.close()
    except Exception:
        pass
    return ''


def get_cmdline_from_pid(pid):
    try:
        f = open('/proc/%s/cmdline' % pid, 'rb')
        try:
            raw = f.read()
        finally:
            f.close()
        if not raw:
            return ''
        raw = raw.replace(b'\x00', b' ').strip()
        return to_unicode(raw)
    except Exception:
        return ''


def read_meminfo_kb():
    mem = {}
    try:
        f = open('/proc/meminfo', 'r')
        try:
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        mem[parts[0]] = int(parts[1])
                    except Exception:
                        pass
        finally:
            f.close()
    except Exception:
        pass
    return mem


def get_available_kb(mem=None):
    if mem is None:
        mem = read_meminfo_kb()
    # MemAvailable is the kernel estimate of RAM that can be used without swapping.
    available = mem.get('MemAvailable:', 0)
    if available <= 0:
        available = (mem.get('MemFree:', 0) + mem.get('Buffers:', 0) +
                     mem.get('Cached:', 0) + mem.get('SReclaimable:', 0) -
                     mem.get('Shmem:', 0))
    return max(0, available)


def get_process_memory_kb(pid, collect_pss=True):
    """Return (name, rss_kb, pss_kb, swap_kb).

    PSS is preferred for ranking when smaps_rollup is available because it
    accounts shared pages proportionally. Falls back to RSS on older kernels.
    """
    name = ''
    rss_kb = 0
    pss_kb = 0
    swap_kb = 0
    try:
        f = open('/proc/%s/status' % pid, 'r')
        try:
            for line in f:
                if line.startswith('Name:'):
                    name = line.split()[1].strip()
                elif line.startswith('VmRSS:'):
                    rss_kb = int(line.split()[1].strip())
                elif line.startswith('VmSwap:'):
                    swap_kb = int(line.split()[1].strip())
        finally:
            f.close()
    except Exception:
        return '', 0, 0, 0

    rollup = '/proc/%s/smaps_rollup' % pid
    if collect_pss and os.path.exists(rollup):
        try:
            f = open(rollup, 'r')
            try:
                for line in f:
                    if line.startswith('Pss:'):
                        pss_kb = int(line.split()[1].strip())
                    elif line.startswith('SwapPss:') and swap_kb <= 0:
                        try:
                            swap_kb = int(line.split()[1].strip())
                        except Exception:
                            pass
            finally:
                f.close()
        except Exception:
            pss_kb = 0
    return name, rss_kb, pss_kb, swap_kb


def get_process_ram_mb(pid):
    name, rss_kb, pss_kb, swap_kb = get_process_memory_kb(pid)
    return name, int(rss_kb / 1024)

def get_enigma2_plugin_memory_mb(pid, total_mb):
    plugin_mb = 0
    details = {}
    smaps_path = '/proc/%s/smaps' % pid
    try:
        if not os.path.exists(smaps_path):
            return 0, {}
        f = open(smaps_path, 'r')
        try:
            current_path = ''
            current_rss = 0
            for raw in f:
                line = raw.strip()
                if not line:
                    continue
                if line.startswith('Rss:'):
                    try:
                        current_rss = int(line.split()[1])
                    except Exception:
                        current_rss = 0
                    if current_path:
                        normalized = current_path.lower()
                        if '/plugins/' in normalized or '/extensions/' in normalized or '/python/plugins/' in normalized:
                            plugin_mb += int(current_rss / 1024)
                            base = os.path.basename(current_path)
                            if not base:
                                base = current_path
                            details[base] = details.get(base, 0) + int(current_rss / 1024)
                elif line[0].isdigit() and '-' in line:
                    parts = line.split()
                    if len(parts) >= 6:
                        current_path = parts[-1]
                    else:
                        current_path = ''
                    current_rss = 0
        finally:
            f.close()
    except Exception as e:
        print("[MemOrganize] smaps parse error: %s" % str(e))
        return 0, {}
    if plugin_mb > total_mb:
        plugin_mb = 0
        details = {}
    return plugin_mb, details


def build_process_entries(include_enigma_split=True, collect_pss=False):
    temp = []
    grouped_procs = {}
    try:
        pids = os.listdir('/proc')
    except Exception:
        pids = []
    for pid in pids:
        if not pid.isdigit():
            continue
        name, rss_kb, pss_kb, swap_kb = get_process_memory_kb(pid, collect_pss=collect_pss)
        ram_mb = int(rss_kb / 1024)
        pss_mb = int(pss_kb / 1024) if pss_kb > 0 else ram_mb
        swap_mb = int(swap_kb / 1024)
        if ram_mb <= 0:
            continue
        if name == 'enigma2' and include_enigma_split:
            plugin_mb, plugin_details = get_enigma2_plugin_memory_mb(pid, ram_mb)
            core_mb = ram_mb - plugin_mb
            cmdline = get_cmdline_from_pid(pid)
            if plugin_mb > 0:
                if core_mb > 0:
                    temp.append({
                        'name': 'enigma2 Core',
                        'original_name': 'enigma2',
                        'ram': core_mb,
                        'pss': min(core_mb, pss_mb),
                        'swap': swap_mb,
                        'pid': pid,
                        'details': cmdline,
                        'journal': ''
                    })
                detail_parts = []
                top_items = sorted(plugin_details.items(), key=lambda item: item[1], reverse=True)[:5]
                for item_name, item_mb in top_items:
                    detail_parts.append('%s=%dMB' % (item_name, item_mb))
                temp.append({
                    'name': 'enigma2 Plugins',
                    'original_name': 'enigma2_plugins',
                    'ram': plugin_mb,
                    'pss': min(plugin_mb, pss_mb),
                    'swap': 0,
                    'pid': pid,
                    'details': ', '.join(detail_parts),
                    'journal': ''
                })
            else:
                temp.append({
                    'name': 'enigma2 (Core + Plugins)',
                    'original_name': 'enigma2',
                    'ram': ram_mb,
                    'pss': pss_mb,
                    'swap': swap_mb,
                    'pid': pid,
                    'details': cmdline,
                    'journal': ''
                })
        else:
            # Clean dynamic names for grouping (e.g., smbd[192.168...])
            group_name = name
            if name.startswith('smbd'):
                group_name = 'smbd'
            elif name.startswith('dropbear'):
                group_name = 'dropbear'
                
            if group_name in grouped_procs:
                grouped_procs[group_name]['ram'] += ram_mb
                grouped_procs[group_name]['pss'] += pss_mb
                grouped_procs[group_name]['swap'] += swap_mb
                grouped_procs[group_name]['count'] += 1
                grouped_procs[group_name]['pids'].append(pid)
            else:
                grouped_procs[group_name] = {
                    'name': group_name,
                    'original_name': group_name,
                    'ram': ram_mb,
                    'pss': pss_mb,
                    'swap': swap_mb,
                    'pid': pid,
                    'pids': [pid],
                    'count': 1,
                    'details': get_cmdline_from_pid(pid),
                    'journal': ''
                }

    for group_name, data in grouped_procs.items():
        if data['count'] > 1:
            data['name'] = "%s (x%d)" % (data['name'], data['count'])
            data['pid'] = " ".join(data['pids'])
        temp.append(data)
        
    return sorted(temp, key=lambda item: item.get('pss', item.get('ram', 0)), reverse=True)


def load_history_db():
    folder, history_file = get_history_paths()
    data = read_json_file(history_file, default={})
    if not isinstance(data, dict):
        data = {}
    if 'events' not in data or not isinstance(data.get('events'), list):
        data['events'] = []
    data['history_folder'] = folder
    data['history_file'] = history_file
    return data


def save_history_db(data):
    folder, history_file = get_history_paths()
    data['history_folder'] = folder
    data['history_file'] = history_file
    if 'events' not in data or not isinstance(data.get('events'), list):
        data['events'] = []
    data['events'] = data['events'][-MAX_HISTORY_ITEMS:]
    return write_json_file(history_file, data)


def append_history_event(event_type, summary, processes=None, details=''):
    history_lock.acquire()
    try:
        data = load_history_db()
        event = {
            'time': time.strftime('%Y-%m-%d %H:%M:%S'),
            'type': event_type,
            'summary': summary,
            'details': details,
            'processes': processes or []
        }
        data['events'].append(event)
        return save_history_db(data)
    finally:
        history_lock.release()


def build_snapshot_for_history(reason_text):
    proc_entries = build_process_entries(include_enigma_split=False)[:SNAPSHOT_TOP_COUNT]
    processes = []
    for item in proc_entries:
        processes.append({
            'name': item.get('name', ''),
            'original_name': item.get('original_name', ''),
            'ram': item.get('ram', 0),
            'pss': item.get('pss', 0),
            'swap': item.get('swap', 0),
            'pid': item.get('pid', ''),
            'details': item.get('details', ''),
            'journal': item.get('journal', '')
        })
    return append_history_event('snapshot', reason_text, processes=processes)


def start_history_snapshot(reason_text):
    global bg_worker_running
    if bg_worker_running:
        return False
    bg_worker_running = True

    def worker():
        global bg_worker_running
        try:
            build_snapshot_for_history(reason_text)
        except Exception as e:
            append_runtime_log(reason_text, e)
        finally:
            bg_worker_running = False
    if not start_detached_job(worker):
        bg_worker_running = False
        return False
    return True


def record_history_background():
    start_history_snapshot('Background tracking snapshot')


def ensure_bg_timer_running():
    global bg_timer, bg_timer_conn
    if bg_timer is None:
        bg_timer = eTimer()
        bg_timer_conn = bind_timer(bg_timer, record_history_background)
    try:
        bg_timer.start(max(30000, int(config.plugins.MemOrganize.monitor_interval.value) * 1000), False)
    except Exception as e:
        print('[MemOrganize] timer start error: %s' % str(e))


def stop_bg_timer():
    global bg_timer
    try:
        if bg_timer is not None:
            bg_timer.stop()
    except Exception:
        pass


def autostart(reason, **kwargs):
    if reason == 0:
        start_detached_job(auto_enable_configured_swap)
        if config.plugins.MemOrganize.run_on_boot.value:
            start_history_snapshot('Boot snapshot')
        if config.plugins.MemOrganize.run_in_bg.value:
            ensure_bg_timer_running()
    elif reason == 1:
        stop_bg_timer()


def get_mount_points():
    mounts = []
    seen = set()
    virtual_fs = set(['proc', 'sysfs', 'devtmpfs', 'devpts', 'tmpfs', 'cgroup', 'cgroup2',
                      'overlay', 'squashfs', 'debugfs', 'tracefs', 'pstore', 'securityfs',
                      'mqueue', 'rpc_pipefs', 'fusectl', 'autofs'])
    try:
        f = open('/proc/mounts', 'r')
        try:
            for line in f:
                parts = line.split()
                if len(parts) < 3:
                    continue
                dev, mountp, fstype = parts[0], parts[1], parts[2]
                mountp = mountp.replace('\\040', ' ')
                if fstype in virtual_fs:
                    continue
                if mountp in seen or not os.path.isdir(mountp):
                    continue
                seen.add(mountp)
                mounts.append((dev, mountp, fstype))
        finally:
            f.close()
    except Exception:
        pass
    return mounts


def get_fs_numbers(path):
    try:
        st = os.statvfs(path)
        total = st.f_blocks * st.f_frsize
        free = st.f_bavail * st.f_frsize
        used = max(0, total - free)
        return total, used, free
    except Exception:
        return 0, 0, 0


def human_size(num_bytes):
    value = float(num_bytes)
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    unit = units[0]
    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            break
        value /= 1024.0
    if unit in ['B', 'KB']:
        return '%.0f %s' % (value, unit)
    return '%.2f %s' % (value, unit)


def read_diagnostic_file(path, limit=262144):
    try:
        f = open(path, 'rb')
        try:
            data = f.read(limit)
        finally:
            f.close()
        return to_unicode(data)
    except Exception:
        return ''


def get_diagnostic_log_path():
    return '/tmp/MemOrganize_diagnostic.log'


def _create_diagnostic_log():
    path = get_diagnostic_log_path()
    lines = []
    lines.append('MEMORGANIZE PERFORMANCE DIAGNOSTIC')
    lines.append('=' * 72)
    lines.append('Created: %s' % time.strftime('%Y-%m-%d %H:%M:%S'))
    lines.append('Plugin version: %s' % (read_diagnostic_file(os.path.join(PLUGIN_PATH, 'Ver.txt'), 128).strip() or 'Unknown'))
    try:
        lines.append('System: %s' % ' '.join([to_unicode(x) for x in os.uname()]))
    except Exception:
        pass
    model = read_diagnostic_file('/proc/stb/info/model', 256).strip()
    if model:
        lines.append('Receiver model: %s' % model)
    image_version = read_diagnostic_file('/etc/image-version', 8192).strip()
    if image_version:
        lines.append('')
        lines.append('[IMAGE VERSION]')
        lines.append(image_version)

    health = get_system_health()
    lines.append('')
    lines.append('[SYSTEM HEALTH]')
    lines.append('Uptime: %.2f hours' % (health.get('uptime', 0) / 3600.0))
    lines.append('Load average: %.2f %.2f %.2f' % (health.get('load1', 0), health.get('load5', 0), health.get('load15', 0)))
    lines.append('CPU cores: %d' % get_cpu_count())
    lines.append('Processes: %d' % health.get('processes', 0))
    lines.append('Zombies: %d' % health.get('zombies', 0))

    lines.append('')
    lines.append('[MEMORY]')
    mem = read_meminfo_kb()
    for key in sorted(mem.keys()):
        lines.append('%-24s %d kB' % (key, mem.get(key, 0)))

    lines.append('')
    lines.append('[SWAP]')
    swaps = get_active_swaps()
    if swaps:
        for item in swaps:
            lines.append('%s | type=%s | size=%s | used=%s | priority=%s' % (
                item.get('path', ''), item.get('type', ''),
                human_size(item.get('size_kb', 0) * 1024),
                human_size(item.get('used_kb', 0) * 1024),
                item.get('priority', '')))
    else:
        lines.append('No active swap.')
    lines.append('Configured path: %s' % config.plugins.MemOrganize.swap_path.value)
    lines.append('Configured size: %s MB' % config.plugins.MemOrganize.swap_size.value)
    lines.append('Swappiness: %s' % str(get_swappiness()))

    lines.append('')
    lines.append('[VM ACTIVITY]')
    vmstat = read_diagnostic_file('/proc/vmstat')
    wanted_vm = ['pswpin', 'pswpout', 'pgfault', 'pgmajfault', 'pgscan_kswapd', 'pgscan_direct', 'allocstall']
    for raw in vmstat.splitlines():
        key = raw.split()[0] if raw.split() else ''
        if key in wanted_vm or key.startswith('allocstall_'):
            lines.append(raw)

    lines.append('')
    lines.append('[STORAGE]')
    for dev, mountp, fstype in get_mount_points():
        total, used, free = get_fs_numbers(mountp)
        lines.append('%s | %s | %s | total=%s used=%s available=%s' % (
            dev, mountp, fstype, human_size(total), human_size(used), human_size(free)))

    lines.append('')
    lines.append('[TOP MEMORY PROCESSES]')
    processes = []
    try:
        pids = os.listdir('/proc')
    except Exception:
        pids = []
    for pid in pids:
        if not pid.isdigit():
            continue
        name, rss_kb, pss_kb, swap_kb = get_process_memory_kb(pid, collect_pss=False)
        if rss_kb <= 0 and swap_kb <= 0:
            continue
        processes.append((max(pss_kb, rss_kb), name, pid, rss_kb, pss_kb, swap_kb))
    processes.sort(key=lambda item: item[0], reverse=True)
    lines.append('%-8s %-24s %10s %10s %10s' % ('PID', 'NAME', 'RSS MB', 'PSS MB', 'SWAP MB'))
    for rank, name, pid, rss_kb, pss_kb, swap_kb in processes[:40]:
        lines.append('%-8s %-24s %10.1f %10.1f %10.1f' % (
            pid, to_unicode(name)[:24], rss_kb / 1024.0, pss_kb / 1024.0, swap_kb / 1024.0))

    lines.append('')
    lines.append('[DISK ACTIVITY]')
    diskstats = read_diagnostic_file('/proc/diskstats')
    lines.extend(diskstats.splitlines())

    lines.append('')
    lines.append('[RELEVANT KERNEL MESSAGES]')
    try:
        kernel_lines = capture_command_output(['dmesg'], limit=524288, timeout_seconds=15).splitlines()
        keywords = ['error', 'fail', 'oom', 'out of memory', 'swap', 'blocked', 'i/o', 'dvb', 'demux', 'decoder']
        relevant = [line for line in kernel_lines if any(word in line.lower() for word in keywords)]
        lines.extend(relevant[-200:])
    except Exception as e:
        lines.append('Could not read kernel messages: %s' % str(e))

    try:
        data = '\n'.join([to_unicode(line) for line in lines]) + '\n'
        f = open(path, 'wb')
        try:
            f.write(data.encode('utf-8', 'replace'))
        finally:
            f.close()
        return True, path, 'Diagnostic log created successfully.'
    except Exception as e:
        return False, path, 'Could not create diagnostic log: %s' % str(e)


def create_diagnostic_log():
    try:
        return _create_diagnostic_log()
    except Exception as e:
        path = get_diagnostic_log_path()
        message = 'Diagnostic collection failed: %s' % str(e)
        try:
            f = open(path, 'wb')
            try:
                fallback = 'MEMORGANIZE DIAGNOSTIC ERROR\nCreated: %s\n%s\n' % (
                    time.strftime('%Y-%m-%d %H:%M:%S'), message)
                f.write(fallback.encode('utf-8', 'replace'))
            finally:
                f.close()
            return False, path, '%s A fallback log was saved.' % message
        except Exception:
            return False, path, message


def get_external_mounts():
    result = []
    seen_devices = set()
    try:
        root_device = os.stat('/').st_dev
    except Exception:
        root_device = None
    prefixes = ('/media/', '/mnt/', '/autofs/', '/hdd', '/data')
    for dev, mountp, fstype in get_mount_points():
        if mountp == '/':
            continue
        if mountp.startswith(prefixes) or mountp in ['/media', '/mnt']:
            try:
                device_id = os.stat(mountp).st_dev
            except Exception:
                device_id = (dev, mountp)
            # Some images expose the root filesystem again below /media. It is
            # internal flash, not an external storage target.
            if root_device is not None and device_id == root_device and mountp != '/data':
                continue
            if device_id in seen_devices:
                continue
            seen_devices.add(device_id)
            result.append((dev, mountp, fstype))
    return result


def get_allocated_size(path):
    try:
        st = os.lstat(path)
        blocks = getattr(st, 'st_blocks', 0)
        if blocks:
            return int(blocks) * 512
        return int(st.st_size)
    except Exception:
        return 0


def get_cleanup_tree_size(path, max_entries=25000):
    total = 0
    entries = 0
    try:
        if os.path.islink(path):
            return get_allocated_size(path), 1
        for dirpath, dirnames, filenames in os.walk(path, topdown=True, followlinks=False):
            for name in list(dirnames):
                full = os.path.join(dirpath, name)
                if os.path.islink(full):
                    total += get_allocated_size(full)
                    entries += 1
                    try:
                        dirnames.remove(name)
                    except Exception:
                        pass
            for name in filenames:
                total += get_allocated_size(os.path.join(dirpath, name))
                entries += 1
                if entries >= max_entries:
                    return total, entries
    except Exception:
        pass
    return total, entries


def cleanup_path_is_safe(path, allowed_root):
    try:
        real_path = os.path.realpath(path)
        real_root = os.path.realpath(allowed_root)
        if real_root in ['', '/']:
            return False
        if real_path == real_root:
            return False
        return real_path.startswith(real_root.rstrip('/') + '/')
    except Exception:
        return False


def add_cleanup_file(candidates, path, label, allowed_root):
    try:
        if not cleanup_path_is_safe(path, allowed_root):
            return
        if os.path.isfile(path) or os.path.islink(path):
            candidates.append({
                'kind': 'file', 'path': path, 'label': label,
                'allowed_root': allowed_root, 'size': get_allocated_size(path), 'count': 1
            })
    except Exception:
        pass


def add_cleanup_directory(candidates, path, label, allowed_root):
    try:
        if not cleanup_path_is_safe(path, allowed_root):
            return
        if not os.path.isdir(path) or os.path.islink(path):
            return
        size, count = get_cleanup_tree_size(path)
        if count > 0:
            candidates.append({
                'kind': 'directory', 'path': path, 'label': label,
                'allowed_root': allowed_root, 'size': size, 'count': count
            })
    except Exception:
        pass


def add_matching_cleanup_files(candidates, folder, patterns, label, allowed_root, min_age_days=0):
    try:
        if not os.path.isdir(folder):
            return
        now = time.time()
        min_age = float(min_age_days) * 86400.0
        for name in os.listdir(folder):
            if not any(fnmatch.fnmatch(name, pattern) for pattern in patterns):
                continue
            path = os.path.join(folder, name)
            try:
                if min_age and (now - os.lstat(path).st_mtime) < min_age:
                    continue
            except Exception:
                continue
            add_cleanup_file(candidates, path, label, allowed_root)
    except Exception:
        pass


def get_safe_cleanup_candidates(mode):
    candidates = []
    if mode == 'root':
        # Package archives and user caches can be regenerated. Package databases,
        # settings, EPG data, picons and plugin files are deliberately excluded.
        add_matching_cleanup_files(candidates, '/var/cache/opkg', ['*.ipk', '*.tmp'], 'OPKG package cache', '/var/cache/opkg')
        add_matching_cleanup_files(candidates, '/var/cache/apt/archives', ['*.deb'], 'APT package cache', '/var/cache/apt/archives')
        add_cleanup_directory(candidates, '/home/root/.cache', 'User application cache', '/home/root')
        for folder in ['/tmp', '/home/root', '/home/root/logs']:
            add_matching_cleanup_files(
                candidates, folder,
                ['enigma2_crash_*.log', 'enigma2_debug_*.log', 'gstreamer_*.log', 'core.*'],
                'Old crash/debug file', folder, min_age_days=3)
    else:
        remote_fs = set(['nfs', 'nfs4', 'cifs', 'smbfs'])
        seen = set()
        for dev, mountp, fstype in get_external_mounts():
            if (fstype or '').lower() in remote_fs:
                continue
            try:
                key = (os.stat(mountp).st_dev, os.path.realpath(mountp))
            except Exception:
                key = (dev, mountp)
            if key in seen:
                continue
            seen.add(key)
            for trash_name in ['.Trash-0', '.Trash-1000', '.Trashes']:
                add_cleanup_directory(candidates, os.path.join(mountp, trash_name), 'External storage trash', mountp)
            for cache_name in ['.cache', '.thumbnails']:
                add_cleanup_directory(candidates, os.path.join(mountp, cache_name), 'External generated cache', mountp)
            add_matching_cleanup_files(
                candidates, mountp,
                ['enigma2_crash_*.log', 'enigma2_debug_*.log', 'core.*'],
                'Old external crash/debug file', mountp, min_age_days=7)
    return candidates


def remove_cleanup_directory_contents(path, allowed_root):
    if not cleanup_path_is_safe(path, allowed_root) or not os.path.isdir(path) or os.path.islink(path):
        return 0, 1
    removed = 0
    errors = 0
    try:
        for dirpath, dirnames, filenames in os.walk(path, topdown=False, followlinks=False):
            for name in filenames:
                target = os.path.join(dirpath, name)
                try:
                    removed += get_allocated_size(target)
                    os.unlink(target)
                except Exception:
                    errors += 1
            for name in dirnames:
                target = os.path.join(dirpath, name)
                try:
                    if os.path.islink(target):
                        removed += get_allocated_size(target)
                        os.unlink(target)
                    else:
                        os.rmdir(target)
                except Exception:
                    errors += 1
    except Exception:
        errors += 1
    return removed, errors


def execute_safe_cleanup(candidates):
    removed = 0
    errors = 0
    for item in candidates:
        path = item.get('path', '')
        allowed_root = item.get('allowed_root', '')
        if not cleanup_path_is_safe(path, allowed_root):
            errors += 1
            continue
        if item.get('kind') == 'directory':
            freed, failed = remove_cleanup_directory_contents(path, allowed_root)
            removed += freed
            errors += failed
        else:
            try:
                removed += get_allocated_size(path)
                os.unlink(path)
            except Exception:
                errors += 1
    return removed, errors


PROTECTED_PLUGIN_NAMES = set([
    'memorganize', 'softwaremanager', 'packagemanager', 'skinselector',
    'hotplug', 'networksetup', 'nimmanager', 'satconfig', 'videomode',
    'positionersetup', 'factoryreset', 'softwareupdate'
])


def get_plugin_directory_size(path):
    total = 0
    try:
        for dirpath, dirnames, filenames in os.walk(path, topdown=True, followlinks=False):
            dirnames[:] = [name for name in dirnames if not os.path.islink(os.path.join(dirpath, name))]
            for name in filenames:
                total += get_allocated_size(os.path.join(dirpath, name))
    except Exception:
        pass
    return total


def get_plugin_package_owners():
    owners = {}
    info_roots = ['/var/lib/opkg/info', '/var/lib/dpkg/info']
    plugin_markers = ['/Plugins/Extensions/', '/Plugins/SystemPlugins/']
    for info_root in info_roots:
        if not os.path.isdir(info_root):
            continue
        try:
            list_files = [name for name in os.listdir(info_root) if name.endswith('.list')]
        except Exception:
            list_files = []
        for list_name in list_files:
            package_name = list_name[:-5]
            list_path = os.path.join(info_root, list_name)
            try:
                f = open(list_path, 'r')
                try:
                    for raw_line in f:
                        installed_path = raw_line.strip()
                        for marker in plugin_markers:
                            marker_pos = installed_path.find(marker)
                            if marker_pos < 0:
                                continue
                            remainder = installed_path[marker_pos + len(marker):].lstrip('/')
                            plugin_name = remainder.split('/', 1)[0]
                            if not plugin_name:
                                continue
                            plugin_root = installed_path[:marker_pos + len(marker)] + plugin_name
                            owners[os.path.normpath(plugin_root)] = package_name
                finally:
                    f.close()
            except Exception:
                pass
    return owners


def plugin_is_disabled(path):
    if os.path.exists(os.path.join(path, '.memorganize-disabled')):
        return True
    for name in ['plugin.py', 'plugin.pyc', 'plugin.pyo']:
        if os.path.exists(os.path.join(path, name + '.memorganize-disabled')):
            return True
    return False


def get_installed_plugin_entries():
    entries = []
    owners = get_plugin_package_owners()
    roots = [
        ('Extensions', '/usr/lib/enigma2/python/Plugins/Extensions'),
        ('SystemPlugins', '/usr/lib/enigma2/python/Plugins/SystemPlugins')
    ]
    for category, root in roots:
        if not os.path.isdir(root):
            continue
        try:
            names = os.listdir(root)
        except Exception:
            names = []
        for name in names:
            path = os.path.join(root, name)
            if not os.path.isdir(path) or os.path.islink(path) or name.startswith('.'):
                continue
            disabled = plugin_is_disabled(path)
            package = owners.get(os.path.normpath(path), '')
            protected = (name.lower() in PROTECTED_PLUGIN_NAMES or category == 'SystemPlugins')
            entries.append({
                'name': name,
                'category': category,
                'path': path,
                'size': get_plugin_directory_size(path),
                'package': package,
                'disabled': disabled,
                'protected': protected
            })
    entries.sort(key=lambda item: item.get('size', 0), reverse=True)
    return entries


def get_package_files(package_name):
    if not package_name:
        return set()
    for info_root in ['/var/lib/opkg/info', '/var/lib/dpkg/info']:
        path = os.path.join(info_root, package_name + '.list')
        if not os.path.isfile(path):
            continue
        try:
            f = open(path, 'r')
            try:
                return set([os.path.realpath(line.strip()) for line in f if line.strip()])
            finally:
                f.close()
        except Exception:
            pass
    return set()


def find_plugin_processes(plugin):
    result = []
    plugin_path = os.path.realpath(plugin.get('path', ''))
    package_files = get_package_files(plugin.get('package', ''))
    for pid in os.listdir('/proc'):
        if not pid.isdigit():
            continue
        name = get_proc_name_from_pid(pid)
        if not name or name in WHITELIST or name == 'enigma2':
            continue
        cmdline = get_cmdline_from_pid(pid)
        matched = bool(plugin_path and plugin_path in cmdline)
        if not matched and package_files:
            try:
                executable = os.path.realpath('/proc/%s/exe' % pid)
                matched = executable in package_files
            except Exception:
                pass
        if matched:
            memory = get_process_memory_kb(pid)[1]
            result.append({'pid': int(pid), 'name': name, 'memory': memory})
    return result


def set_plugin_disabled(plugin, disable):
    if plugin.get('protected'):
        return False, 'This system plugin is protected.'
    path = plugin.get('path', '')
    if not os.path.isdir(path) or os.path.islink(path):
        return False, 'Plugin folder is not available.'
    suffix = '.memorganize-disabled'
    renamed = []
    try:
        if disable:
            loadable_names = []
            for name in ['plugin.py', 'plugin.pyc', 'plugin.pyo']:
                source = os.path.join(path, name)
                target = source + suffix
                if os.path.exists(source):
                    if os.path.exists(target):
                        return False, 'A disabled backup already exists.'
                    loadable_names.append(name)
            if not loadable_names:
                return False, 'No loadable plugin entry file was found.'
            for name in loadable_names:
                source = os.path.join(path, name)
                target = source + suffix
                os.rename(source, target)
                renamed.append((target, source))
            marker = open(os.path.join(path, '.memorganize-disabled'), 'w')
            try:
                marker.write('Disabled by Memory Organize\n')
            finally:
                marker.close()
            return True, 'Plugin disabled. Restart the Enigma2 GUI to apply the change.'
        restored = 0
        for name in ['plugin.py', 'plugin.pyc', 'plugin.pyo']:
            target = os.path.join(path, name)
            source = target + suffix
            if os.path.exists(source):
                if os.path.exists(target):
                    return False, 'Enable failed because an active entry file already exists.'
                os.rename(source, target)
                restored += 1
        marker_path = os.path.join(path, '.memorganize-disabled')
        if os.path.exists(marker_path):
            os.unlink(marker_path)
        if restored:
            return True, 'Plugin enabled. Restart the Enigma2 GUI to apply the change.'
        return False, 'No disabled plugin backup was found.'
    except Exception as e:
        if disable:
            for source, target in reversed(renamed):
                try:
                    if os.path.exists(source) and not os.path.exists(target):
                        os.rename(source, target)
                except Exception:
                    pass
        return False, 'Plugin state change failed: %s' % str(e)


def uninstall_plugin_package(plugin):
    if plugin.get('protected'):
        return False, 'This system plugin is protected.'
    package = plugin.get('package', '')
    if not package or any(ch not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+.-_:' for ch in package):
        return False, 'A verified package name was not found. Manual folder deletion is not allowed.'
    if os.path.exists('/usr/bin/apt-get'):
        rc = run_quiet_command(['/usr/bin/apt-get', '-y', 'remove', package], timeout_seconds=300)
    elif os.path.exists('/usr/bin/opkg'):
        rc = run_quiet_command(['/usr/bin/opkg', 'remove', package], timeout_seconds=300)
    else:
        return False, 'No supported package manager was found.'
    if rc == 0:
        return True, 'Package uninstalled successfully. Restart the Enigma2 GUI if requested.'
    return False, 'Package manager failed. The plugin was not removed.'


def get_swap_storage_name(mountp):
    low = mountp.lower()
    if mountp == '/':
        return 'Internal flash'
    if 'hdd' in low or 'harddisk' in low:
        return 'Hard disk'
    if 'usb' in low:
        return 'USB storage'
    if mountp == '/data' or low.startswith('/data/'):
        return 'Data partition'
    return 'Storage: %s' % mountp


def get_swap_storage_candidates():
    candidates = []
    seen = set()
    mounts = list(get_external_mounts())
    root_mount = get_mount_for_path('/')
    if root_mount:
        mounts.append(root_mount)
    else:
        mounts.append(('', '/', 'unknown'))

    for dev, mountp, fstype in mounts:
        if mountp in seen or not os.path.isdir(mountp):
            continue
        seen.add(mountp)
        total, used, free = get_fs_numbers(mountp)
        if total <= 0:
            continue
        path = '/swapfile' if mountp == '/' else os.path.join(mountp, 'swapfile')
        ok, reason = validate_swap_location(path, 64)
        if os.path.exists(path):
            ok = False
            reason = 'A swap file already exists here. Delete it from Swap Manager before creating a new one.'
        low = mountp.lower()
        priority = 5
        if 'hdd' in low or 'harddisk' in low:
            priority = 0
        elif 'usb' in low:
            priority = 1
        elif mountp == '/data' or low.startswith('/data/'):
            priority = 2
        elif mountp == '/':
            priority = 9
        candidates.append({
            'device': dev,
            'mount': mountp,
            'path': path,
            'fstype': fstype,
            'total': total,
            'used': used,
            'free': free,
            'name': get_swap_storage_name(mountp),
            'valid': ok,
            'reason': reason,
            'priority': priority,
        })
    candidates.sort(key=lambda item: (item.get('priority', 5), item.get('mount', '')))
    return candidates


def find_existing_swaps():
    found = []
    seen = set()
    for item in get_active_swaps():
        path = item.get('path', '')
        if not path or path in seen:
            continue
        seen.add(path)
        found.append({
            'path': path,
            'size_bytes': int(item.get('size_kb', 0)) * 1024,
            'active': True,
            'type': item.get('type', 'swap'),
        })

    paths = []
    configured = config.plugins.MemOrganize.swap_path.value
    if configured:
        paths.append(configured)
    for storage in get_swap_storage_candidates():
        path = storage.get('path', '')
        if path:
            paths.append(path)

    for path in paths:
        if not path or path in seen or not os.path.isfile(path):
            continue
        try:
            size_bytes = os.path.getsize(path)
        except Exception:
            size_bytes = 0
        seen.add(path)
        found.append({
            'path': path,
            'size_bytes': size_bytes,
            'active': False,
            'type': 'file',
        })
    return found


def swap_size_text(size_bytes):
    size_bytes = max(0, int(size_bytes or 0))
    size_mb = size_bytes / (1024.0 * 1024.0)
    if size_mb >= 900:
        return '%.2f GB' % (size_mb / 1024.0)
    if size_mb >= 1:
        return '%.0f MB' % size_mb
    return human_size(size_bytes)


def existing_swap_message(swaps):
    lines = ['Swap was found on this device.']
    total = 0
    for item in swaps:
        size_bytes = item.get('size_bytes', 0)
        total += size_bytes
        state = 'Active' if item.get('active') else 'Present but inactive'
        lines.append('')
        lines.append('Path: %s' % item.get('path', ''))
        lines.append('Size: %s' % swap_size_text(size_bytes))
        lines.append('Status: %s' % state)
        if item.get('type') == 'partition':
            lines.append('Type: Dedicated swap partition')
        else:
            lines.append('Type: Swap file')
    if len(swaps) > 1:
        lines.append('')
        lines.append('Total swap capacity: %s' % swap_size_text(total))
    lines.append('')
    if any(item.get('active') for item in swaps):
        lines.append('Swap is already active, so no additional swap is needed.')
    else:
        lines.append('An inactive swap file was found, so another one will not be created.')
    if any(item.get('type') == 'partition' for item in swaps):
        lines.append('For safety, this plugin will not delete a swap partition.')
    else:
        lines.append('The swap file can be enabled or deleted from Swap Manager.')
    return '\n'.join(lines)


def get_swap_size_suggestions(storage):
    free_mb = int(storage.get('free', 0) / (1024 * 1024))
    # Keep at least 10% free and never consume the last 128 MB.
    reserve_mb = max(128, int(free_mb * 0.10))
    maximum_mb = max(0, free_mb - reserve_mb)
    allowed = [64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384]
    sizes = [size for size in allowed if size <= maximum_mb]
    if not sizes:
        return [], reserve_mb

    mem = read_meminfo_kb()
    ram_mb = int(mem.get('MemTotal:', 0) / 1024)
    target = min(1024, max(256, int(ram_mb / 2))) if ram_mb else 512
    recommended = sizes[-1]
    for size in sizes:
        if size >= target:
            recommended = size
            break
    result = []
    for size in sizes:
        result.append({
            'size': size,
            'remaining_mb': max(0, free_mb - size),
            'recommended': size == recommended,
        })
    return result, reserve_mb


def save_swap_configuration(path, size_mb):
    size_choices = [('64','64 MB'),('128','128 MB'),('256','256 MB'),('512','512 MB'),('1024','1 GB'),('2048','2 GB'),('4096','4 GB'),('8192','8 GB'),('16384','16 GB')]
    try:
        config.plugins.MemOrganize.swap_size.setChoices(size_choices, default=str(size_mb))
    except TypeError:
        config.plugins.MemOrganize.swap_size.setChoices(size_choices)
    config.plugins.MemOrganize.swap_path.value = path
    config.plugins.MemOrganize.swap_size.value = str(size_mb)
    config.plugins.MemOrganize.swap_path.save()
    config.plugins.MemOrganize.swap_size.save()
    configfile.save()


class FlashUsageScreen(Screen):
    skinName = 'FlashUsageScreen'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self['lbl_title'] = Label('Internal Flash Usage')
        self['lbl_fs_root'] = Label('Flash Summary:')
        self['lbl_val_root'] = Label('...')
        self['lbl_fs_data'] = Label('Data Summary:')
        self['lbl_val_data'] = Label('...')
        
        self['lbl_col_name'] = Label('Package / Plugin')
        self['lbl_col_mem'] = Label('Flash Usage')

        self['key_red'] = Label('Back')
        self['key_green'] = Label('Refresh')
        self['key_yellow'] = Label('Safe Cleanup')
        self['key_blue'] = Label('Plugin Manager')
        self['lbl_help'] = Label('Loading flash data...')
        for n in ['btn_red','btn_green','btn_yellow','btn_blue']:
            self[n] = Pixmap()
        self.onLayoutFinish.append(self.apply_button_icons)

        self.list_data = []
        self['history_list'] = List(self.list_data)
        self._pending_cleanup = []
        self._cleanup_mode = 'root'
        self._destructive_running = False
        self._async_job = BackgroundJob()
        self.onClose.append(self._async_job.close)

        self['actions'] = ActionMap([
            'ColorActions', 'OkCancelActions', 'DirectionActions', 'MenuActions', 'InfobarMenuActions', 'NumberActions'
        ],
        {
            'red': self.request_close,
            'green': self.refresh_log,
            'yellow': self.request_cleanup,
            'blue': self.open_plugin_manager,
            'cancel': self.request_close,
            'up': self.move_up,
            'down': self.move_down,
            'left': self.page_up,
            'right': self.page_down,
            'ok': self.request_cleanup,
            'menu': self.toggle_storage_view,
            'showMainMenu': self.toggle_storage_view,
        }, -1)

        self.current_mode = 'root'
        self.onLayoutFinish.append(self.refresh_log)

    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red','btn_green':'green','btn_yellow':'yellow','btn_blue':'blue'})

    def request_close(self):
        if self._destructive_running:
            self.session.open(MessageBox, 'A storage task is still running. Please wait.', MessageBox.TYPE_INFO, timeout=6)
            return
        self.close()

    def move_up(self):
        self['history_list'].selectPrevious()

    def move_down(self):
        self['history_list'].selectNext()

    def page_up(self):
        for i in range(10):
            self['history_list'].selectPrevious()

    def page_down(self):
        for i in range(10):
            self['history_list'].selectNext()

    def show_root_flash(self):
        self.current_mode = 'root'
        self['lbl_title'].setText('Internal Flash Usage')
        self.refresh_log()

    def show_data_flash(self):
        self.current_mode = 'data'
        self['lbl_title'].setText('External/Data Storage Usage')
        self.refresh_log()

    def toggle_storage_view(self):
        if self.current_mode == 'root':
            self.show_data_flash()
        else:
            self.show_root_flash()

    def open_plugin_manager(self):
        self.session.open(PluginManagerScreen)

    def request_cleanup(self):
        self._cleanup_mode = self.current_mode
        if not self._async_job.start(get_safe_cleanup_candidates, self._cleanup_candidates_ready, self.current_mode):
            self['lbl_help'].setText('Please wait for the current storage task')
            return
        self['lbl_help'].setText('Searching for safe temporary files in background...')

    def _cleanup_candidates_ready(self, success, result):
        if not success:
            self.session.open(MessageBox, 'Cleanup scan failed: %s' % to_unicode(result), MessageBox.TYPE_ERROR, timeout=7)
            self.refresh_log()
            return
        candidates = result
        self._pending_cleanup = candidates
        if not candidates:
            self.session.open(
                MessageBox,
                'No safe temporary files were found. No files were deleted.',
                MessageBox.TYPE_INFO,
                timeout=6)
            return
        total_size = sum([item.get('size', 0) for item in candidates])
        total_files = sum([item.get('count', 0) for item in candidates])
        location = 'internal flash and temporary memory' if self._cleanup_mode == 'root' else 'external storage'
        message = (
            'Safe cleanup is ready for %s.\n\n'
            'Reclaimable: %s\n'
            'Items: %d\n\n'
            'Only known cache, old crash/debug, and trash files will be removed. '
            'Settings, plugins, recordings, picons, EPG data, and swap files are protected.\n\n'
            'Continue?') % (location, human_size(total_size), total_files)
        self.session.openWithCallback(self.run_cleanup, MessageBox, message, MessageBox.TYPE_YESNO)

    def run_cleanup(self, confirmed):
        if not confirmed:
            self._pending_cleanup = []
            return
        candidates = self._pending_cleanup
        self._pending_cleanup = []
        if not self._async_job.start(execute_safe_cleanup, self._cleanup_finished, candidates):
            self._pending_cleanup = candidates
            self['lbl_help'].setText('Please wait for the current storage task')
            return
        self._destructive_running = True
        self['lbl_help'].setText('Removing safe temporary files in background...')

    def _cleanup_finished(self, success, result):
        self._destructive_running = False
        if success:
            removed, errors = result
        else:
            removed, errors = 0, 1
            append_runtime_log('Safe cleanup', result)
        append_history_event(
            'action' if errors == 0 else 'warning',
            'Safe storage cleanup',
            details='%s | errors=%d | mode=%s' % (human_size(removed), errors, self._cleanup_mode))
        self.refresh_log()
        message = 'Safe cleanup completed.\n\nSpace released: %s' % human_size(removed)
        if errors:
            message += '\nSkipped/failed items: %d' % errors
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=8)

    def get_fs_usage(self, path):
        try:
            st = os.statvfs(path)
            total = (st.f_blocks * st.f_frsize)
            free = (st.f_bavail * st.f_frsize)
            used = total - free
            total_gb = total / (1024.0 * 1024.0 * 1024.0)
            used_gb = used / (1024.0 * 1024.0 * 1024.0)
            return "Size: %.2f GB Used: %.2f GB Free: %.2f GB" % (total_gb, used_gb, (free / (1024.0 * 1024.0 * 1024.0)))
        except Exception:
            return "Size: N/A Used: N/A"

    def get_dir_size_mb(self, start_path, deadline=None, max_entries=8000):
        total_size = 0
        entries = 0
        try:
            for dirpath, dirnames, filenames in os.walk(start_path, topdown=True, followlinks=False):
                if deadline is not None and time.time() >= deadline:
                    break
                for f in filenames:
                    entries += 1
                    if entries >= max_entries or (deadline is not None and time.time() >= deadline):
                        return total_size / (1024.0 * 1024.0)
                    fp = os.path.join(dirpath, f)
                    if not os.path.islink(fp) and os.path.isfile(fp):
                        total_size += os.path.getsize(fp)
        except Exception:
            pass
        return total_size / (1024.0 * 1024.0)

    def refresh_log(self):
        mode = self.current_mode
        if not self._async_job.start(self._collect_refresh_data, self._refresh_ready, mode):
            self['lbl_help'].setText('Please wait for the current storage task')
            return
        self['lbl_val_root'].setText(self.get_fs_usage('/'))
        self['lbl_help'].setText('Scanning storage in background...')
        self['history_list'].updateList([(('', ''), to_display_string('Scanning...'), to_display_string('Please wait'))])

    def _collect_refresh_data(self, mode):
        list_data = []
        root_summary = self.get_fs_usage('/')
        data_path = '/data'
        if not os.path.ismount(data_path):
            external_mounts = get_external_mounts()
            data_path = external_mounts[0][1] if external_mounts else '/'
        data_summary = self.get_fs_usage(data_path)
        paths_to_scan = []
        if mode == 'root':
            paths_to_scan = [
                '/usr/lib/enigma2/python/Plugins/Extensions/',
                '/usr/lib/enigma2/python/Plugins/SystemPlugins/'
            ]
            help_text = 'RED Back | GREEN Refresh | YELLOW/OK Scan & Clean | BLUE Plugins | MENU External/Data'
        else:
            help_text = 'RED Back | GREEN Refresh | YELLOW/OK Scan & Clean | BLUE Plugins | MENU Internal Flash'
            ext = get_external_mounts()
            for dev, mountp, fstype in ext:
                total, used, free = get_fs_numbers(mountp)
                if total <= 0:
                    continue
                pct = int((used * 100.0) / total) if total else 0
                name = '%s  [%s]' % (mountp, fstype)
                value = '%s / %s  (%d%%)' % (human_size(used), human_size(total), pct)
                list_data.append((('', ''), to_display_string(name), to_display_string(value)))
            if not list_data:
                list_data.append((('', ''), to_display_string('No external/data mount found'), to_display_string('-')))
            return mode, root_summary, data_summary, help_text, list_data, time.strftime('%H:%M:%S')
        
        items = []
        scan_deadline = time.time() + 8.0
        for base_path in paths_to_scan:
            if time.time() >= scan_deadline:
                break
            if os.path.exists(base_path):
                try:
                    dirs = os.listdir(base_path)
                except Exception:
                    dirs = []
                for d in dirs:
                    if time.time() >= scan_deadline:
                        break
                    full_path = os.path.join(base_path, d)
                    if os.path.isdir(full_path):
                        if d in ['proc', 'sys', 'dev']:
                             continue
                        size_mb = self.get_dir_size_mb(full_path, deadline=scan_deadline)
                        if size_mb > 0.01:
                            items.append(('%s/%s' % (os.path.basename(base_path.rstrip('/')), d), size_mb))

        items.sort(key=lambda x: x[1], reverse=True)

        for name, size_mb in items:
            size_str = "%.2f MB" % size_mb
            list_data.append((('', ''), to_display_string(name), to_display_string(size_str)))

        if not list_data:
            list_data.append((('', ''), to_display_string('No plugin packages found'), to_display_string('0.00 MB')))
        return mode, root_summary, data_summary, help_text, list_data, time.strftime('%H:%M:%S')

    def _refresh_ready(self, success, result):
        if not success:
            self['lbl_help'].setText('Storage scan failed. See /tmp/MemOrganize_runtime.log')
            return
        mode, root_summary, data_summary, help_text, list_data, updated_at = result
        if mode != self.current_mode:
            self.refresh_log()
            return
        self.list_data = list_data
        self['lbl_val_root'].setText(root_summary)
        self['lbl_val_data'].setText(data_summary)
        self['lbl_help'].setText('%s | Updated: %s' % (help_text, updated_at))
        self['history_list'].updateList(self.list_data)



class PluginManagerScreen(Screen):
    skinName = 'PluginManagerScreen'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.entries = []
        self._pending_plugin = None
        self._destructive_running = False
        self._async_job = BackgroundJob()
        self.onClose.append(self._async_job.close)
        self['summary'] = Label('Installed Enigma2 plugins, flash usage, package ownership and current state.')
        self['lbl_col_name'] = Label('Plugin')
        self['lbl_col_type'] = Label('Type / Package')
        self['lbl_col_size'] = Label('Flash')
        self['lbl_col_state'] = Label('State')
        self['plugin_list'] = List([])
        self['key_red'] = Label('Back')
        self['key_green'] = Label('Rescan')
        self['key_yellow'] = Label('Enable / Disable')
        self['key_blue'] = Label('Uninstall')
        self['lbl_help'] = Label('RED Back | GREEN Rescan | YELLOW Enable/Disable | BLUE Uninstall | OK Details | 8 Stop Process')
        for name in ['btn_red', 'btn_green', 'btn_yellow', 'btn_blue']:
            self[name] = Pixmap()
        self['actions'] = ActionMap([
            'ColorActions', 'OkCancelActions', 'DirectionActions', 'NumberActions'
        ], {
            'red': self.request_close,
            'cancel': self.request_close,
            'green': self.refresh_plugins,
            'yellow': self.request_toggle,
            'blue': self.request_uninstall,
            'ok': self.show_details,
            '8': self.request_stop_process,
            'up': self.move_up,
            'down': self.move_down,
            'left': self.page_up,
            'right': self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.apply_button_icons)
        self.onLayoutFinish.append(self.refresh_plugins)

    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red', 'btn_green':'green', 'btn_yellow':'yellow', 'btn_blue':'blue'})

    def request_close(self):
        if self._destructive_running:
            self.session.open(MessageBox, 'A plugin task is still running. Please wait.', MessageBox.TYPE_INFO, timeout=6)
            return
        self.close()

    def move_up(self):
        self['plugin_list'].selectPrevious()

    def move_down(self):
        self['plugin_list'].selectNext()

    def page_up(self):
        for index in range(10):
            self['plugin_list'].selectPrevious()

    def page_down(self):
        for index in range(10):
            self['plugin_list'].selectNext()

    def current_plugin(self):
        current = self['plugin_list'].getCurrent()
        return current[0] if current else None

    def refresh_plugins(self):
        if not self._async_job.start(get_installed_plugin_entries, self._plugins_ready):
            self['summary'].setText('Please wait for the current plugin task')
            return
        self['summary'].setText('Scanning installed plugins in background...')
        self['plugin_list'].updateList([(None, to_display_string('Scanning...'), '', '', to_display_string('Please wait'))])

    def _plugins_ready(self, success, result):
        self.entries = []
        if not success:
            self['summary'].setText('Plugin scan failed. See /tmp/MemOrganize_runtime.log')
            return
        plugins = result
        total_size = 0
        disabled_count = 0
        for plugin in plugins:
            total_size += plugin.get('size', 0)
            if plugin.get('disabled'):
                disabled_count += 1
            state = 'Protected' if plugin.get('protected') else ('Disabled' if plugin.get('disabled') else 'Enabled')
            package = plugin.get('package') or 'Package unknown'
            type_package = '%s | %s' % (plugin.get('category', ''), package)
            self.entries.append((
                plugin,
                to_display_string(plugin.get('name', 'Unknown')),
                to_display_string(type_package),
                to_display_string(human_size(plugin.get('size', 0))),
                to_display_string(state)
            ))
        if not self.entries:
            self.entries.append((None, to_display_string('No plugins found'), '', '0 B', '-'))
        self['plugin_list'].updateList(self.entries)
        self['summary'].setText('%d plugins | %s on flash | %d disabled' % (len(plugins), human_size(total_size), disabled_count))

    def show_details(self):
        plugin = self.current_plugin()
        if not plugin:
            return
        processes = find_plugin_processes(plugin)
        process_lines = []
        for process in processes:
            process_lines.append('%s (PID %d, %.1f MB)' % (
                process.get('name', ''), process.get('pid', 0), process.get('memory', 0) / 1024.0))
        if not process_lines:
            process_lines.append('No standalone process detected. It may run inside Enigma2.')
        text = (
            'Plugin: %s\n'
            'Category: %s\n'
            'State: %s\n'
            'Flash usage: %s\n'
            'Package: %s\n'
            'Path: %s\n\n'
            'Related processes:\n%s') % (
                plugin.get('name', ''), plugin.get('category', ''),
                'Disabled' if plugin.get('disabled') else 'Enabled',
                human_size(plugin.get('size', 0)), plugin.get('package') or 'Unknown',
                plugin.get('path', ''), '\n'.join(process_lines))
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO)

    def request_toggle(self):
        plugin = self.current_plugin()
        if not plugin:
            return
        if plugin.get('protected'):
            self.session.open(MessageBox, 'This system plugin is protected and cannot be changed.', MessageBox.TYPE_INFO, timeout=6)
            return
        self._pending_plugin = plugin
        action = 'enable' if plugin.get('disabled') else 'disable'
        text = '%s plugin "%s"?\n\nThe change is reversible and requires an Enigma2 GUI restart.' % (action.capitalize(), plugin.get('name', ''))
        self.session.openWithCallback(self.run_toggle, MessageBox, text, MessageBox.TYPE_YESNO)

    def run_toggle(self, confirmed):
        plugin = self._pending_plugin
        self._pending_plugin = None
        if not confirmed or not plugin:
            return
        disable = not plugin.get('disabled')
        ok, message = set_plugin_disabled(plugin, disable)
        append_history_event('action' if ok else 'error', 'Plugin state change', details='%s | %s' % (plugin.get('name', ''), message))
        self.refresh_plugins()
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=8)

    def request_stop_process(self):
        plugin = self.current_plugin()
        if not plugin:
            return
        processes = find_plugin_processes(plugin)
        if not processes:
            self.session.open(MessageBox, 'No safe standalone process was found. Plugins running inside Enigma2 cannot be stopped individually.', MessageBox.TYPE_INFO, timeout=7)
            return
        self._pending_plugin = plugin
        details = '\n'.join(['%s (PID %d)' % (item.get('name', ''), item.get('pid', 0)) for item in processes])
        self.session.openWithCallback(
            self.run_stop_process, MessageBox,
            'Stop the standalone process for "%s"?\n\n%s\n\nA graceful TERM signal will be used.' % (plugin.get('name', ''), details),
            MessageBox.TYPE_YESNO)

    def run_stop_process(self, confirmed):
        plugin = self._pending_plugin
        self._pending_plugin = None
        if not confirmed or not plugin:
            return
        stopped = 0
        failed = 0
        for process in find_plugin_processes(plugin):
            try:
                os.kill(process.get('pid'), 15)
                stopped += 1
            except Exception:
                failed += 1
        message = 'Stop request sent to %d process(es).' % stopped
        if failed:
            message += '\nFailed: %d' % failed
        append_history_event('action' if stopped else 'error', 'Stop plugin process', details='%s | %s' % (plugin.get('name', ''), message))
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO if stopped else MessageBox.TYPE_ERROR, timeout=7)

    def request_uninstall(self):
        plugin = self.current_plugin()
        if not plugin:
            return
        if plugin.get('protected'):
            self.session.open(MessageBox, 'This system plugin is protected and cannot be uninstalled.', MessageBox.TYPE_INFO, timeout=6)
            return
        if not plugin.get('package'):
            self.session.open(MessageBox, 'A verified package owner was not found. Manual folder deletion is blocked for safety.', MessageBox.TYPE_ERROR, timeout=7)
            return
        self._pending_plugin = plugin
        self.session.openWithCallback(
            self.confirm_uninstall_again, MessageBox,
            'Uninstall plugin "%s" using package "%s"?\n\nThis removes the installed package.' % (plugin.get('name', ''), plugin.get('package', '')),
            MessageBox.TYPE_YESNO)

    def confirm_uninstall_again(self, confirmed):
        if not confirmed or not self._pending_plugin:
            self._pending_plugin = None
            return
        plugin = self._pending_plugin
        self.session.openWithCallback(
            self.run_uninstall, MessageBox,
            'Final confirmation:\n\nUninstall "%s" now?\n\nPlugin settings may remain, but the package files will be removed.' % plugin.get('name', ''),
            MessageBox.TYPE_YESNO)

    def run_uninstall(self, confirmed):
        plugin = self._pending_plugin
        self._pending_plugin = None
        if not confirmed or not plugin:
            return
        if plugin.get('disabled'):
            restored, restore_message = set_plugin_disabled(plugin, False)
            if not restored:
                self.session.open(MessageBox, 'Uninstall stopped: %s' % restore_message, MessageBox.TYPE_ERROR, timeout=8)
                return
        if not self._async_job.start(self._uninstall_worker, self._uninstall_ready, plugin):
            self.session.open(MessageBox, 'Please wait for the current plugin task.', MessageBox.TYPE_INFO, timeout=6)
            return
        self._destructive_running = True
        self['summary'].setText('Uninstalling package in background...')

    def _uninstall_worker(self, plugin):
        ok, message = uninstall_plugin_package(plugin)
        append_history_event('action' if ok else 'error', 'Uninstall plugin package', details='%s | %s' % (plugin.get('name', ''), message))
        return plugin, ok, message

    def _uninstall_ready(self, success, result):
        self._destructive_running = False
        if success:
            plugin, ok, message = result
        else:
            ok, message = False, 'Package uninstall failed: %s' % to_unicode(result)
        self.refresh_plugins()
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=9)


class MemoryOrganizeScreen(Screen):
    skinName = 'MemoryOrganizeScreen'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        version_text = 'Ver Unknown'
        try:
            f = open(os.path.join(PLUGIN_PATH, "Ver.txt"), 'r')
            try:
                v_text = f.read().strip()
                if v_text:
                    if v_text.lower().startswith("ver"):
                        version_text = v_text
                    else:
                        version_text = 'Ver ' + v_text
            finally:
                f.close()
        except Exception:
            pass
            
        self.setTitle('Memory Organize')
        self['lbl_title'] = Label('Memory Organize By iet5')
        self['lbl_version'] = Label(version_text)
        self['lbl_total_ram'] = Label('RAM Total')
        self['lbl_used_ram'] = Label('RAM Used')
        self['lbl_free_ram'] = Label('RAM Available')
        self['lbl_col_name'] = Label('Process / Component')
        self['lbl_col_mem'] = Label('Usage')
        self['lbl_status'] = Label('Reading system status...')

        self['key_red'] = Label('Exit')
        self['key_green'] = Label('Refresh')
        self['key_yellow'] = Label('Free Memory Cache')
        self['key_blue'] = Label('Kill')
        self['lbl_help'] = Label('RED Exit | GREEN Refresh | YELLOW Cache | BLUE Kill | OK Details | MENU Flash | INFO Memory | 0 Setup | 7 Log | 8 Growth | 9 Swap')
        for n in ['btn_red','btn_green','btn_yellow','btn_blue']:
            self[n] = Pixmap()
        self.onLayoutFinish.append(self.apply_button_icons)

        self.proc_list = []
        self['process_list'] = List(self.proc_list)
        self._cpu_prev_total = get_total_cpu_ticks()
        self._cpu_prev = {}
        self._async_job = BackgroundJob()
        self.onClose.append(self._close_resources)

        self['actions'] = ActionMap([
            'ColorActions', 'OkCancelActions', 'DirectionActions', 'MenuActions', 'InfobarMenuActions', 'NumberActions'
        ],
        {
            'red': self.close,
            'green': self.manual_refresh,
            'yellow': self.free_cache,
            'blue': self.clear_process,
            'menu': self.open_history,
            'showMainMenu': self.open_history,
            'info': self.open_detailed_info,
            'ok': self.open_process_details,
            '0': self.open_settings,
            '7': self.create_performance_log,
            '9': self.open_swap,
            '8': self.open_growth,
            'cancel': self.close,
            'up': self.move_up,
            'down': self.move_down,
            'left': self.page_up,
            'right': self.page_down,
        }, -1)

        self.timer = eTimer()
        self.timer_conn = bind_timer(self.timer, self.update_screen)
        self.timer.start(15000, False)
        self.onLayoutFinish.append(self.initial_refresh)

    def _close_resources(self):
        try:
            self.timer.stop()
        except Exception:
            pass
        self._async_job.close()

    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red','btn_green':'green','btn_yellow':'yellow','btn_blue':'blue'})

    def move_up(self):
        self['process_list'].selectPrevious()

    def move_down(self):
        self['process_list'].selectNext()

    def page_up(self):
        for i in range(10):
            self['process_list'].selectPrevious()

    def page_down(self):
        for i in range(10):
            self['process_list'].selectNext()

    def open_settings(self):
        try: self.timer.stop()
        except Exception: pass
        self.session.openWithCallback(self.on_history_closed, MemOrganizeSettingsScreen)

    def open_swap(self):
        try: self.timer.stop()
        except Exception: pass
        self.session.openWithCallback(self.on_history_closed, SwapManagerScreen)

    def open_growth(self):
        try: self.timer.stop()
        except Exception: pass
        self.session.openWithCallback(self.on_history_closed, MemoryGrowthScreen)

    def create_performance_log(self):
        if not self._async_job.start(create_diagnostic_log, self._performance_log_ready):
            self['lbl_status'].setText('Please wait for the current maintenance task')
            return
        self['lbl_status'].setText('Creating diagnostic log in background...')

    def _performance_log_ready(self, success, result):
        if success:
            ok, path, msg = result
        else:
            ok, path, msg = False, get_diagnostic_log_path(), 'Diagnostic collection failed: %s' % to_unicode(result)
        text = '%s\n\nFile:\n%s\n\nSend this file for performance analysis.' % (msg, path)
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR)
        self.update_screen()

    def calc_cpu_percent(self, pid_text, total_now, cpu_count):
        total_prev=self._cpu_prev_total
        dt=max(1,total_now-total_prev)
        proc_now=0
        key=str(pid_text)
        for pid in key.split():
            if pid.isdigit(): proc_now += get_proc_cpu_ticks(pid)
        proc_prev=self._cpu_prev.get(key,proc_now)
        self._cpu_prev[key]=proc_now
        dp=max(0,proc_now-proc_prev)
        return (float(dp)*float(cpu_count)*100.0)/float(dt)

    def open_history(self):
        try:
            self.timer.stop()
        except Exception:
            pass
        self.session.openWithCallback(self.on_history_closed, FlashUsageScreen)

    def open_detailed_info(self):
        try:
            self.timer.stop()
        except Exception:
            pass
        
        if not isDreamOS:
            try:
                from Screens.About import MemoryInfo
                self.session.openWithCallback(self.on_history_closed, MemoryInfo)
                return
            except ImportError:
                pass
                
        self.session.openWithCallback(self.on_history_closed, DetailedMemoryInfoScreen)

    def on_history_closed(self, *args):
        try:
            self.timer.start(15000, False)
        except Exception:
            pass
        self.update_screen()

    def initial_refresh(self):
        # Opening the screen must not write to disk or wake a sleeping HDD.
        self.update_screen()

    def manual_refresh(self):
        self.update_screen()
        if start_history_snapshot('Manual refresh snapshot'):
            self['lbl_status'].setText('Refresh completed; snapshot is saving in background')
        else:
            self['lbl_status'].setText('Refresh completed; a snapshot is already being saved')

    def update_screen(self):
        self.update_stats()
        self.update_list()

    def update_stats(self):
        try:
            mem = read_meminfo_kb()
            mem_total = mem.get('MemTotal:', 0)
            available = get_available_kb(mem)
            used = max(0, mem_total - available)
            cache = mem.get('Cached:', 0) + mem.get('SReclaimable:', 0)
            swap_total = mem.get('SwapTotal:', 0)
            swap_free = mem.get('SwapFree:', 0)
            swap_used = max(0, swap_total - swap_free)
            self['lbl_total_ram'].setText('Total: %d MB' % int(mem_total / 1024))
            self['lbl_used_ram'].setText('Used: %d MB' % int(used / 1024))
            self['lbl_free_ram'].setText('Available: %d MB' % int(available / 1024))
            health=get_system_health(include_process_states=False)
            cpu_count=get_cpu_count()
            warning=''
            ram_pct=int((used*100.0)/mem_total) if mem_total else 0
            if ram_pct >= int(config.plugins.MemOrganize.warn_ram_percent.value): warning=' | RAM HIGH'
            if health.get('load1',0) > cpu_count*1.5: warning += ' | LOAD HIGH'
            if health.get('zombies',0)>0: warning += ' | Zombie:%d' % health.get('zombies',0)
            self['lbl_status'].setText('Cache:%dMB | Swap used:%dMB | Load:%.2f%s' % (int(cache/1024),int(swap_used/1024),health.get('load1',0),warning))
        except Exception as e:
            print('[MemOrganize] meminfo error: %s' % str(e))

    def update_list(self):
        temp = build_process_entries(include_enigma_split=False)[:80]
        total_now = get_total_cpu_ticks()
        cpu_count = get_cpu_count()
        self.proc_list = []
        for i in temp:
            rss = int(i.get('ram', 0))
            pss = int(i.get('pss', rss))
            swap = int(i.get('swap', 0))
            if pss != rss:
                info = 'PSS %d | RSS %d MB' % (pss, rss)
            else:
                info = '%d MB' % rss
            if swap > 0:
                info += ' | SW %d' % swap
            cpu = self.calc_cpu_percent(i.get('pid',''), total_now, cpu_count)
            if cpu >= 0.1:
                info += ' | CPU %.1f%%' % cpu
            p_name = i.get('name', '-')
            orig_name = i.get('original_name', '')
            
            desc = PROCESS_DESCRIPTIONS.get(orig_name, '')
            if desc:
                display_name = '%s   [%s]' % (p_name, desc)
            else:
                display_name = p_name
                
            self.proc_list.append(((i.get('pid', ''), orig_name), to_display_string(display_name), to_display_string(info)))
        self['process_list'].updateList(self.proc_list)
        self._cpu_prev_total = total_now

    def free_cache(self):
        mem = read_meminfo_kb()
        before = int(get_available_kb(mem) / 1024)
        msg = ('Linux automatically reclaims file cache when applications need RAM.\n\n'
               'This action safely writes pending data to storage, then releases file page cache '
               'and reclaimable directory/inode caches (value 3). '
               'It does not free memory leaked/held by Enigma2 processes and can temporarily slow disk access.\n\n'
               'Available RAM now: %d MB\n\nRun safe cache cleanup?') % before
        self.session.openWithCallback(self.do_free_cache, MessageBox, msg, MessageBox.TYPE_YESNO)

    def do_free_cache(self, res):
        if not res:
            return
        if not self._async_job.start(perform_cache_cleanup, self._cache_cleanup_ready):
            self['lbl_status'].setText('Please wait for the current maintenance task')
            return
        self['lbl_status'].setText('Releasing cache safely in background...')

    def _cache_cleanup_ready(self, success, result):
        if success:
            ret, released, after = result
        else:
            ret, released, after = 1, 0, int(get_available_kb() / 1024)
            append_runtime_log('Cache cleanup', result)
        self.update_screen()
        if ret == 0:
            self['lbl_status'].setText('Memory cache released: %d MB | Available RAM: %d MB' % (released, after))
        else:
            self['lbl_status'].setText('Cache cleanup failed or permission denied')

    def open_process_details(self):
        sel = self['process_list'].getCurrent()
        if not sel:
            return
        pid_text, original_name = sel[0]
        self.session.open(ProcessDetailsScreen, pid_text, original_name)

    def clear_process(self):
        sel = self['process_list'].getCurrent()
        if sel:
            pid, original_name = sel[0]
            if original_name in WHITELIST or original_name in ['enigma2_plugins', 'enigma2']:
                self.session.open(MessageBox, 'SYSTEM PROTECTED: ' + original_name, MessageBox.TYPE_INFO)
                return
            self.target_pid = pid
            self.target_name = original_name
            self.session.openWithCallback(self.kill_it, MessageBox, 'Kill ' + original_name + '?', MessageBox.TYPE_YESNO)

    def kill_it(self, res):
        if res:
            ret = 0
            try:
                for pid in str(self.target_pid).split():
                    if pid.isdigit():
                        os.kill(int(pid), 9)
            except Exception:
                ret = 1
            append_history_event('action', 'Kill process request', details='%s pid=%s result=%s' % (self.target_name, str(self.target_pid), str(ret)))
            self.update_screen()
            self['lbl_status'].setText('Kill command sent to %s' % self.target_name)

class ProcessDetailsScreen(Screen):
    skinName = 'ProcessDetailsScreen'

    def __init__(self, session, pid_text, original_name):
        Screen.__init__(self, session)
        self.pid_text = str(pid_text)
        self.original_name = original_name
        self['text'] = ScrollLabel('')
        self['key_red'] = Label('Close')
        self['btn_red'] = Pixmap()
        self.onLayoutFinish.append(self.apply_button_icons)
        self['actions'] = ActionMap(['ColorActions', 'OkCancelActions', 'DirectionActions'], {
            'red': self.close, 'cancel': self.close,
            'up': self.page_up, 'down': self.page_down,
            'left': self.page_up, 'right': self.page_down
        }, -1)
        self.onLayoutFinish.append(self.populate_info)

    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red'})

    def page_up(self):
        self['text'].pageUp()

    def page_down(self):
        self['text'].pageDown()

    def populate_info(self):
        try:
            lines = ['Process Details', '']
            total_rss = total_pss = total_swap = 0
            found = 0
            for pid in self.pid_text.split():
                if not pid.isdigit():
                    continue
                if not os.path.isdir('/proc/%s' % pid):
                    lines.append('PID %s is no longer running.' % pid)
                    lines.append('')
                    continue
                name, rss_kb, pss_kb, swap_kb = get_process_memory_kb(pid)
                found += 1
                total_rss += rss_kb
                total_pss += pss_kb if pss_kb > 0 else rss_kb
                total_swap += swap_kb
                lines.append('PID: %s  Name: %s' % (pid, to_unicode(name or self.original_name)))
                lines.append('  PSS: %.1f MB  RSS: %.1f MB  Swap: %.1f MB' % (
                    (pss_kb if pss_kb > 0 else rss_kb) / 1024.0,
                    rss_kb / 1024.0, swap_kb / 1024.0))
                cmd = get_cmdline_from_pid(pid)
                if cmd:
                    lines.append('  Command: %s' % to_unicode(cmd[:220]))
                lines.append('')
            if found:
                lines.append('TOTAL: PSS %.1f MB | RSS %.1f MB | Swap %.1f MB' % (
                    total_pss / 1024.0, total_rss / 1024.0, total_swap / 1024.0))
            else:
                lines.append('No active process data is available for this entry.')
            if self.original_name == 'enigma2_plugins':
                lines.append('')
                lines.append('Note: Enigma2 plugins run inside the Enigma2 Python process. Per-plugin heap RAM cannot be measured reliably from /proc alone.')
            joined = u'\n'.join([to_unicode(line) for line in lines])
        except Exception as error:
            joined = u'Process details could not be read.\n\nError: %s' % to_unicode(error)
        self['text'].setText(to_display_string(joined))



class MemoryGrowthScreen(Screen):
    skinName='MemoryGrowthScreen'
    def __init__(self, session):
        Screen.__init__(self, session)
        self._async_job = BackgroundJob()
        self.onClose.append(self._async_job.close)
        self['text']=ScrollLabel(to_display_string('Memory Growth is loading...'))
        self['key_red']=Label('Close')
        self['key_green']=Label('Capture Sample')
        self['btn_red']=Pixmap()
        self['btn_green']=Pixmap()
        self['actions']=ActionMap(['ColorActions','OkCancelActions','DirectionActions'], {'red':self.close,'cancel':self.close,'green':self.capture_sample,'up':self.page_up,'down':self.page_down,'left':self.page_up,'right':self.page_down}, -1)
        self.onLayoutFinish.append(self.apply_button_icons)
        self.populate()
    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red','btn_green':'green'})
    def page_up(self): self['text'].pageUp()
    def page_down(self): self['text'].pageDown()
    def capture_sample(self):
        if not self._async_job.start(build_snapshot_for_history, self._sample_ready, 'Manual growth sample'):
            self['text'].setText(to_display_string('A memory sample is already being captured. Please wait...'))
            return
        self['text'].setText(to_display_string('Capturing memory sample in background...'))

    def _sample_ready(self, success, result):
        if not success:
            append_runtime_log('MemoryGrowth capture_sample', result)
        self.populate()
    def populate(self):
        try:
            data=load_history_db()
            snaps=[x for x in data.get('events',[]) if x.get('type')=='snapshot' and x.get('processes')]
            snaps=snaps[-12:]
            lines=['Memory Growth / Leak Watch','']
            if len(snaps)<2:
                lines.append('Growth comparison needs at least 2 samples. Press GREEN to capture a sample.')
                lines.append('Change channels or use the receiver, wait a while, then press GREEN again.')
                lines.append('You can also enable Background memory monitor in Settings.')
                lines.append('')
                lines.append('CURRENT TOP MEMORY PROCESSES:')
                lines.append('')
                current_processes = build_process_entries(include_enigma_split=False)[:20]
                if current_processes:
                    for item in current_processes:
                        lines.append('%-30s %d MB' % (to_unicode(item.get('name', 'Unknown')), item.get('pss', item.get('ram', 0))))
                else:
                    lines.append('No process information is currently available.')
            else:
                first,last=snaps[0],snaps[-1]
                a={};b={};counts={}
                for snap, dest in [(first,a),(last,b)]:
                    for item in snap.get('processes',[]):
                        key=to_unicode(item.get('original_name') or item.get('name') or 'Unknown')
                        dest[key]=float(item.get('pss',item.get('ram',0)))
                prev={}; rises={}
                for snap in snaps:
                    now={}
                    for item in snap.get('processes',[]):
                        key=to_unicode(item.get('original_name') or item.get('name') or 'Unknown')
                        now[key]=float(item.get('pss',item.get('ram',0)))
                    for key,val in now.items():
                        if key in prev and val > prev[key]+1.0:
                            rises[key]=rises.get(key,0)+1
                        counts[key]=counts.get(key,0)+1
                    prev=now
                rows=[]
                for key,end in b.items():
                    start=a.get(key,end)
                    delta=end-start
                    if delta>=2.0:
                        rows.append((delta,rises.get(key,0),key,start,end))
                rows.sort(reverse=True)
                lines.append('Samples: %d | %s -> %s' % (len(snaps), first.get('time','?'), last.get('time','?')))
                lines.append('Processes that grew by at least 2 MB:')
                lines.append('')
                if not rows:
                    lines.append('No significant continuous growth detected in this window.')
                else:
                    for delta,rise,key,start,end in rows[:20]:
                        flag='POSSIBLE LEAK' if rise >= max(2,len(snaps)//2) and delta>=10 else 'growth'
                        lines.append('%s: %.1f -> %.1f MB  (+%.1f) | rises %d | %s' % (key,start,end,delta,rise,flag))
                lines.append('')
                lines.append('Note: growth is a warning signal, not proof of a leak. Channel lists, EPG, caches and streaming can legitimately increase memory.')
            joined = u'\n'.join([to_unicode(line) for line in lines])
        except Exception as error:
            append_runtime_log('MemoryGrowth populate', error)
            joined = u'Memory Growth data could not be loaded.\n\nError: %s\n\nLog: /tmp/MemOrganize_runtime.log' % to_unicode(error)
        self['text'].setText(to_display_string(joined))

class MemOrganizeSettingsScreen(Screen, ConfigListScreen):
    skinName = 'MemOrganizeSettingsScreen'
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session=session
        self['key_red']=Label('Cancel')
        self['key_green']=Label('Save')
        self['key_yellow']=Label('Swap screen')
        self['key_blue']=Label('Defaults')
        for n in ['btn_red','btn_green','btn_yellow','btn_blue']:
            self[n]=Pixmap()
        entries=[
            getConfigListEntry('Background memory monitor', config.plugins.MemOrganize.run_in_bg),
            getConfigListEntry('Create boot snapshot', config.plugins.MemOrganize.run_on_boot),
            getConfigListEntry('Monitor interval', config.plugins.MemOrganize.monitor_interval),
            getConfigListEntry('RAM warning level', config.plugins.MemOrganize.warn_ram_percent),
            getConfigListEntry('Flash warning level', config.plugins.MemOrganize.warn_flash_percent),
            getConfigListEntry('Swap file location', config.plugins.MemOrganize.swap_path),
            getConfigListEntry('Swap file size', config.plugins.MemOrganize.swap_size),
            getConfigListEntry('Auto-enable swap after Enigma2 boot', config.plugins.MemOrganize.swap_autoenable),
            getConfigListEntry('Linux swappiness', config.plugins.MemOrganize.swappiness),
        ]
        ConfigListScreen.__init__(self, entries, session=session)
        self['actions']=ActionMap(['ColorActions','OkCancelActions'], {'red':self.cancel,'cancel':self.cancel,'green':self.save,'yellow':self.open_swap,'blue':self.defaults}, -1)
        self.onLayoutFinish.append(self.apply_button_icons)
    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red','btn_green':'green','btn_yellow':'yellow','btn_blue':'blue'})
    def save(self):
        for x in self['config'].list:
            try: x[1].save()
            except Exception: pass
        configfile.save()
        if config.plugins.MemOrganize.run_in_bg.value: ensure_bg_timer_running()
        else: stop_bg_timer()
        self.close()
    def cancel(self):
        for x in self['config'].list:
            try: x[1].cancel()
            except Exception: pass
        self.close()
    def open_swap(self):
        self.session.open(SwapManagerScreen)
    def defaults(self):
        config.plugins.MemOrganize.monitor_interval.value='60'
        config.plugins.MemOrganize.warn_ram_percent.value='90'
        config.plugins.MemOrganize.warn_flash_percent.value='90'
        config.plugins.MemOrganize.swap_size.value='256'
        config.plugins.MemOrganize.swap_path.value='/media/hdd/swapfile'
        config.plugins.MemOrganize.swap_autoenable.value=False
        config.plugins.MemOrganize.swappiness.value='10'
        try: self['config'].invalidateCurrent()
        except Exception: pass

class SwapStorageSelectionScreen(Screen):
    skinName = 'SwapStorageSelectionScreen'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self['title'] = Label('Create Swap - Select Storage')
        self['summary'] = Label('Select a writable storage device. Available and total space are shown for every device.')
        self['key_red'] = Label('Back')
        self['key_green'] = Label('Select')
        self['btn_red'] = Pixmap()
        self['btn_green'] = Pixmap()
        self.entries = []
        self.build_list()
        self['storage_list'] = List(self.entries)
        self['actions'] = ActionMap(['ColorActions','OkCancelActions','DirectionActions'], {
            'red': self.close,
            'cancel': self.close,
            'green': self.select_storage,
            'ok': self.select_storage,
            'up': self.move_up,
            'down': self.move_down,
            'left': self.page_up,
            'right': self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.apply_button_icons)

    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red','btn_green':'green'})

    def build_list(self):
        for storage in get_swap_storage_candidates():
            space = 'Available: %s   Total: %s   [%s]' % (
                human_size(storage.get('free', 0)),
                human_size(storage.get('total', 0)),
                storage.get('fstype', 'unknown'))
            if storage.get('valid'):
                status = storage.get('mount', '')
                if storage.get('mount') == '/':
                    status += '   WARNING: internal flash wear'
            else:
                status = 'Unavailable: %s' % storage.get('reason', 'Not suitable for swap')
            self.entries.append((storage, storage.get('name', 'Storage'), space, status))

    def move_up(self):
        self['storage_list'].selectPrevious()

    def move_down(self):
        self['storage_list'].selectNext()

    def page_up(self):
        for i in range(6):
            self['storage_list'].selectPrevious()

    def page_down(self):
        for i in range(6):
            self['storage_list'].selectNext()

    def select_storage(self):
        current = self['storage_list'].getCurrent()
        if not current:
            self.session.open(MessageBox, 'No storage device is available.', MessageBox.TYPE_ERROR, timeout=5)
            return
        storage = current[0]
        if not storage.get('valid'):
            self.session.open(MessageBox, storage.get('reason', 'This storage is not suitable for swap.'), MessageBox.TYPE_ERROR, timeout=6)
            return
        self.session.openWithCallback(self.size_screen_closed, SwapSizeSelectionScreen, storage)

    def size_screen_closed(self, created=False):
        if created:
            self.close(True)


class SwapSizeSelectionScreen(Screen):
    skinName = 'SwapSizeSelectionScreen'

    def __init__(self, session, storage):
        Screen.__init__(self, session)
        self.session = session
        self.storage = storage
        self.creation_succeeded = False
        self._creating = None
        self._async_job = BackgroundJob()
        self.onClose.append(self._async_job.close)
        self['title'] = Label('Create Swap - Select Size')
        self['summary'] = Label('%s | Available: %s | File: %s' % (
            storage.get('name', 'Storage'),
            human_size(storage.get('free', 0)),
            storage.get('path', '')))
        self['key_red'] = Label('Back')
        self['key_green'] = Label('Save & Create')
        self['btn_red'] = Pixmap()
        self['btn_green'] = Pixmap()
        self.entries = []
        suggestions, reserve_mb = get_swap_size_suggestions(storage)
        for item in suggestions:
            size = item.get('size', 0)
            size_text = '%d MB' % size if size < 1024 else ('%.1f GB' % (size / 1024.0))
            remaining = 'Remaining after creation: %s' % human_size(item.get('remaining_mb', 0) * 1024 * 1024)
            note = 'Recommended' if item.get('recommended') else 'Safe option'
            self.entries.append(((storage.get('path'), size), size_text, remaining, note))
        if not self.entries:
            self.entries.append((None, 'Not enough free space', 'At least 64 MB plus a safety reserve is required.', 'Free more space and try again.'))
        self['size_list'] = List(self.entries)
        self['actions'] = ActionMap(['ColorActions','OkCancelActions','DirectionActions'], {
            'red': self.request_close,
            'cancel': self.request_close,
            'green': self.save_and_create,
            'ok': self.save_and_create,
            'up': self.move_up,
            'down': self.move_down,
            'left': self.page_up,
            'right': self.page_down,
        }, -1)
        self.onLayoutFinish.append(self.apply_button_icons)

    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red','btn_green':'green'})

    def request_close(self):
        if self._async_job.running:
            self.session.open(MessageBox, 'Swap creation is still running. Please wait.', MessageBox.TYPE_INFO, timeout=6)
            return
        self.close()

    def move_up(self):
        self['size_list'].selectPrevious()

    def move_down(self):
        self['size_list'].selectNext()

    def page_up(self):
        for i in range(6):
            self['size_list'].selectPrevious()

    def page_down(self):
        for i in range(6):
            self['size_list'].selectNext()

    def save_and_create(self):
        current = self['size_list'].getCurrent()
        if not current or current[0] is None:
            self.session.open(MessageBox, 'There is not enough safe free space on this storage.', MessageBox.TYPE_ERROR, timeout=6)
            return
        path, size = current[0]
        msg = 'Create a %d MB swap file?\n\nStorage: %s\nPath: %s\nAvailable now: %s' % (
            size,
            self.storage.get('name', 'Storage'),
            path,
            human_size(self.storage.get('free', 0)))
        self.session.openWithCallback(self.confirm_create, MessageBox, msg, MessageBox.TYPE_YESNO)

    def confirm_create(self, confirmed):
        if not confirmed:
            return
        current = self['size_list'].getCurrent()
        if not current or current[0] is None:
            return
        path, size = current[0]
        self._creating = (path, size)
        if not self._async_job.start(create_swap_file, self._swap_created, path, size):
            self._creating = None
            self.session.open(MessageBox, 'Please wait for the current swap task.', MessageBox.TYPE_INFO, timeout=6)
            return
        self['summary'].setText('Creating swap file in background. Please wait...')

    def _swap_created(self, success, result):
        creating = self._creating
        self._creating = None
        if not creating:
            return
        path, size = creating
        if success:
            ok, msg = result
        else:
            ok, msg = False, 'Swap creation failed: %s' % to_unicode(result)
        if ok:
            save_swap_configuration(path, size)
        append_history_event('action' if ok else 'error', 'Create swap', details='%s | %s MB | %s' % (path, size, msg))
        self.creation_succeeded = ok
        self.session.openWithCallback(self.result_closed, MessageBox, msg, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=7)

    def result_closed(self, *args):
        if self.creation_succeeded:
            self.close(True)


class SwapManagerScreen(Screen):
    skinName='SwapManagerScreen'
    def __init__(self, session):
        Screen.__init__(self, session)
        self.session=session
        self._async_job = BackgroundJob()
        self.onClose.append(self._async_job.close)
        self['title']=Label('Swap Manager')
        self['status']=ScrollLabel('')
        self['key_red']=Label('Back')
        self['key_green']=Label('Enable / Disable')
        self['key_yellow']=Label('Create')
        self['key_blue']=Label('Delete')
        for n in ['btn_red','btn_green','btn_yellow','btn_blue']:
            self[n]=Pixmap()
        self['actions']=ActionMap(['ColorActions','OkCancelActions','MenuActions'], {'red':self.request_close,'cancel':self.request_close,'green':self.toggle,'yellow':self.create,'blue':self.delete,'menu':self.open_settings}, -1)
        self.onLayoutFinish.append(self.refresh)
        self.onLayoutFinish.append(self.apply_button_icons)
    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red','btn_green':'green','btn_yellow':'yellow','btn_blue':'blue'})
    def request_close(self):
        if self._async_job.running:
            self.session.open(MessageBox, 'A swap task is still running. Please wait.', MessageBox.TYPE_INFO, timeout=6)
            return
        self.close()
    def refresh(self):
        path=config.plugins.MemOrganize.swap_path.value
        size=int(config.plugins.MemOrganize.swap_size.value)
        active=get_active_swaps()
        mem=read_meminfo_kb()
        lines=[]
        lines.append('Configured file: %s' % path)
        lines.append('Configured size: %d MB' % size)
        lines.append('Auto-enable: %s' % ('YES' if config.plugins.MemOrganize.swap_autoenable.value else 'NO'))
        lines.append('Swappiness: %s (configured %s)' % (str(get_swappiness()), config.plugins.MemOrganize.swappiness.value))
        lines.append('File exists: %s' % ('YES' if os.path.exists(path) else 'NO'))
        lines.append('Configured swap active: %s' % ('YES' if swap_is_active(path) else 'NO'))
        lines.append('Kernel swap total: %.1f MB' % (mem.get('SwapTotal:',0)/1024.0))
        lines.append('Kernel swap used: %.1f MB' % ((mem.get('SwapTotal:',0)-mem.get('SwapFree:',0))/1024.0))
        lines.append('')
        lines.append('ACTIVE SWAP DEVICES/FILES:')
        if active:
            for x in active:
                lines.append('%s | %.1f/%.1f MB used | priority %s' % (x['path'],x['used_kb']/1024.0,x['size_kb']/1024.0,x['priority']))
        else:
            lines.append('No active swap.')
        lines.append('')
        ok,msg=validate_swap_location(path,size)
        lines.append('Location check: %s' % msg)
        if path == '/swapfile':
            lines.append('WARNING: Internal flash swap can increase flash wear. HDD/USB/data is preferred.')
        self['status'].setText(to_display_string('\n'.join(lines)))
    def toggle(self):
        path=config.plugins.MemOrganize.swap_path.value
        worker = disable_swap_file if swap_is_active(path) else enable_swap_file
        if not self._async_job.start(worker, self._toggle_ready, path):
            self.session.open(MessageBox, 'Please wait for the current swap task.', MessageBox.TYPE_INFO, timeout=6)
            return
        self['status'].setText(to_display_string('Updating swap state in background...'))

    def _toggle_ready(self, success, result):
        path=config.plugins.MemOrganize.swap_path.value
        if success:
            ok, msg = result
        else:
            ok, msg = False, 'Swap operation failed: %s' % to_unicode(result)
        append_history_event('action','Swap toggle',details='%s | %s' % (path,msg))
        self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=5)
        self.refresh()
    def create(self):
        swaps = find_existing_swaps()
        if swaps:
            self.session.open(MessageBox, existing_swap_message(swaps), MessageBox.TYPE_INFO)
            return
        msg = 'No swap was found on this device.\n\nA new swap file will be created. Do you want to continue?'
        self.session.openWithCallback(self.create_check_closed, MessageBox, msg, MessageBox.TYPE_YESNO)
    def create_check_closed(self, confirmed):
        if confirmed:
            self.session.openWithCallback(self.swap_wizard_closed, SwapStorageSelectionScreen)
    def swap_wizard_closed(self, created=False):
        if created:
            self.refresh()
    def delete(self):
        path=config.plugins.MemOrganize.swap_path.value
        self.session.openWithCallback(self.do_delete,MessageBox,'Disable and DELETE swap file?\n%s' % path,MessageBox.TYPE_YESNO)
    def do_delete(self,res):
        if not res:return
        path=config.plugins.MemOrganize.swap_path.value
        if not self._async_job.start(remove_swap_file, self._delete_ready, path):
            self.session.open(MessageBox, 'Please wait for the current swap task.', MessageBox.TYPE_INFO, timeout=6)
            return
        self['status'].setText(to_display_string('Deleting verified swap file in background...'))

    def _delete_ready(self, success, result):
        path=config.plugins.MemOrganize.swap_path.value
        if success:
            ok, msg = result
        else:
            ok, msg = False, 'Swap deletion failed: %s' % to_unicode(result)
        append_history_event('action' if ok else 'error','Delete swap',details='%s | %s' % (path,msg))
        self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=6)
        self.refresh()
    def open_settings(self):
        self.session.open(MemOrganizeSettingsScreen)

class DetailedMemoryInfoScreen(Screen):
    skinName = 'DetailedMemoryInfoScreen'

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session

        self['text'] = ScrollLabel("")
        self['key_red'] = Label("Close")
        self['btn_red'] = Pixmap()
        self.onLayoutFinish.append(self.apply_button_icons)

        self['actions'] = ActionMap([
            'ColorActions', 'OkCancelActions', 'DirectionActions'
        ],
        {
            'red': self.close,
            'cancel': self.close,
            'up': self.page_up,
            'down': self.page_down,
            'left': self.page_up,
            'right': self.page_down,
        }, -1)

        self.onLayoutFinish.append(self.populate_info)

    def apply_button_icons(self):
        apply_button_icons(self, {'btn_red':'red'})

    def page_up(self):
        self['text'].pageUp()

    def page_down(self):
        self['text'].pageDown()

    def populate_info(self):
        try:
            model = 'Unknown'
            if os.path.exists('/proc/stb/info/model'):
               with open('/proc/stb/info/model', 'r') as f:
                   model = f.read().strip()
        except:
            model = 'Enigma2 Device'

        info = "Memory information for %s:\n\n" % model

        mem = read_meminfo_kb()

        mem_tot = mem.get('MemTotal:', 0)
        mem_free = mem.get('MemFree:', 0)
        mem_available = get_available_kb(mem)
        buffers = mem.get('Buffers:', 0)
        cached = mem.get('Cached:', 0)
        swap_tot = mem.get('SwapTotal:', 0)
        swap_free = mem.get('SwapFree:', 0)

        health=get_system_health()
        info += "SYSTEM HEALTH:\n"
        info += "  Load average: %.2f / %.2f / %.2f (CPUs: %d)\n" % (health.get('load1',0),health.get('load5',0),health.get('load15',0),get_cpu_count())
        info += "  Processes: %d | Zombies: %d\n" % (health.get('processes',0),health.get('zombies',0))
        info += "  Uptime: %.1f hours\n\n" % (health.get('uptime',0)/3600.0)

        info += "RAM (Summary):\n"
        info += "  %-20s %d kB\n" % ("Total memory:", mem_tot)
        info += "  %-20s %d kB\n" % ("Free memory:", mem_free)
        info += "  %-20s %d kB\n" % ("Available memory:", mem_available)
        info += "  %-20s %d kB\n" % ("Buffers:", buffers)
        info += "  %-20s %d kB\n" % ("Cached:", cached)
        info += "  %-20s %d kB\n" % ("Total swap:", swap_tot)
        info += "  %-20s %d kB\n\n" % ("Free swap:", swap_free)

        info += "FLASH:\n"
        try:
            st = os.statvfs('/')
            total = (st.f_blocks * st.f_frsize)
            free = (st.f_bavail * st.f_frsize)
            used = total - free
            info += "  %-20s %.3f GB (%.3f GiB)\n" % ("Total flash:", total / 1000.0**3, total / 1024.0**3)
            info += "  %-20s %.3f GB (%.3f GiB)\n" % ("Used flash:", used / 1000.0**3, used / 1024.0**3)
            info += "  %-20s %.3f GB (%.3f GiB)\n\n" % ("Free flash:", free / 1000.0**3, free / 1024.0**3)
        except Exception:
            info += "  Not available\n\n"

        info += "RAM (Details):\n"
        for k, v in mem.items():
            info += "  %-20s %d kB\n" % (k, v)

        self['text'].setText(to_display_string(info))


def main(session, **kwargs):
    session.open(MemoryOrganizeScreen)


def menu(menuid, **kwargs):
    return [('Memory Organize', main, 'mem_org_main', 1)] if menuid == 'mainmenu' else []


def Plugins(**kwargs):
    return [
        PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART, fnc=autostart),
        PluginDescriptor(name='Memory Organize', description='Safely manage RAM, flash and swap', icon='plugin.png', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
        PluginDescriptor(name='Memory Organize', description='Safely manage RAM, flash and swap', where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
        PluginDescriptor(name='Memory Organize', description='Safely manage RAM, flash and swap', where=PluginDescriptor.WHERE_MENU, fnc=menu)
    ]
